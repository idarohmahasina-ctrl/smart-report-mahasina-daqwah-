
import React, { useState, useEffect, useMemo } from 'react';
import { AttendanceStatus, Student, UserRole, Schedule, AppData, AttendanceRecord } from './views/utils/types.ts';
import { 
  Search, Save, ArrowLeft, Edit, ChevronRight, Minus, AlertCircle, Users as UsersIcon, Calendar as CalendarIcon, Clock, CheckCircle2
} from 'lucide-react';
import { isTeacherMatch } from './views/utils/nameMatchers.ts';

const Attendance: React.FC<AppData & { 
  role: UserRole, 
  currentUser: string, 
  onSave: (recs: AttendanceRecord[]) => void, 
  onUpdate?: (rec: AttendanceRecord) => void, 
  onUpdateStudent?: (s: Student) => void, 
  userEmail?: string 
}> = (props) => {
  const [activeMainTab, setActiveMainTab] = useState<'today' | 'history'>('today');
  const [activeSession, setActiveSession] = useState<Schedule | null>(null);
  
  // History States
  const [historyDateMode, setHistoryDateMode] = useState<'today' | 'custom'>('today');
  const [historyCustomDate, setHistoryCustomDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedHistorySessionKey, setSelectedHistorySessionKey] = useState<string | null>(null);

  const [isEditingRoster, setIsEditingRoster] = useState(false);
  const [tempRoster, setTempRoster] = useState<Student[]>([]);
  const [attendanceMap, setAttendanceMap] = useState<Record<string, { status: AttendanceStatus, note: string }>>({});

  const todayName = new Intl.DateTimeFormat('id-ID', { weekday: 'long' }).format(new Date());
  const todayDateString = new Date().toLocaleDateString('id-ID');
  const isAdmin = props.userEmail?.toLowerCase().trim() === 'idarohmahasina@gmail.com';

  // Target Date for History Filter
  const targetHistoryDateStr = useMemo(() => {
    if (historyDateMode === 'today') return todayDateString;
    const [y, m, d] = historyCustomDate.split('-');
    return `${d}/${m}/${y}`;
  }, [historyDateMode, historyCustomDate, todayDateString]);

  const mySchedules = useMemo(() => {
    if (isAdmin) return props.schedules;
    return props.schedules.filter(s => 
      isTeacherMatch(props.currentUser, s.teacherName, s.assistantTeacherName, s.homeroomTeacherName)
    );
  }, [props.schedules, props.currentUser, isAdmin]);

  const todaySchedules = useMemo(() => {
    return mySchedules.filter(s => {
      if (s.day !== todayName) return false;
      const isAlreadySubmitted = props.attendance.some(a => 
        a.date === todayDateString && 
        a.class === s.class && 
        a.sessionType === s.sessionType
      );
      return !isAlreadySubmitted;
    });
  }, [mySchedules, todayName, props.attendance, todayDateString]);

  // Grouped History Sessions
  const historySessions = useMemo(() => {
    const records = isAdmin ? props.attendance : props.attendance.filter(a => a.recordedBy === props.currentUser);
    const filtered = records.filter(a => a.date === targetHistoryDateStr);
    
    const groups: Record<string, { class: string, sessionType: string, time: string, count: number, records: AttendanceRecord[] }> = {};
    
    filtered.forEach(r => {
      const key = `${r.class}-${r.sessionType}-${r.date}`;
      if (!groups[key]) {
        groups[key] = { 
          class: r.class, 
          sessionType: r.sessionType, 
          time: r.time, 
          count: 0,
          records: []
        };
      }
      groups[key].count++;
      groups[key].records.push(r);
    });
    
    return Object.entries(groups).map(([key, val]) => ({ key, ...val }));
  }, [props.attendance, props.currentUser, isAdmin, targetHistoryDateStr]);

  const viewingHistoryDetail = useMemo(() => {
    if (!selectedHistorySessionKey) return null;
    return historySessions.find(s => s.key === selectedHistorySessionKey);
  }, [selectedHistorySessionKey, historySessions]);

  useEffect(() => {
    if (activeSession) {
      const roster = props.students.filter(s => 
        s.sessionClasses && s.sessionClasses[activeSession.sessionType] === activeSession.class
      ).sort((a, b) => a.name.localeCompare(b.name));
      setTempRoster(roster);
      const initialMap: Record<string, { status: AttendanceStatus, note: string }> = {};
      roster.forEach(s => { initialMap[s.id] = { status: AttendanceStatus.H, note: '' } });
      setAttendanceMap(initialMap);
    }
  }, [activeSession, props.students]);

  const handleSaveAttendance = () => {
    if (tempRoster.length === 0) { alert("Daftar santri kosong."); return; }
    const records: AttendanceRecord[] = tempRoster.map(s => ({
      id: `att-${Date.now()}-${s.id}`,
      studentId: s.id,
      status: attendanceMap[s.id]?.status || AttendanceStatus.H,
      note: attendanceMap[s.id]?.note || '',
      date: todayDateString,
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      recordedBy: props.currentUser,
      class: activeSession!.class,
      sessionType: activeSession!.sessionType
    }));
    props.onSave(records);
    alert("Absensi Berhasil Disimpan!");
    setActiveSession(null);
  };

  const getStatusLabel = (status: AttendanceStatus) => {
    switch (status) {
      case AttendanceStatus.H: return 'H';
      case AttendanceStatus.S: return 'S';
      case AttendanceStatus.I: return 'I';
      case AttendanceStatus.T: return 'T';
      case AttendanceStatus.A: return 'A';
      default: return '?';
    }
  };

  // UI INPUT ABSEN
  if (activeSession) {
    return (
      <div className="space-y-3 animate-in slide-in-from-right-10 duration-500 pb-32">
        <div className="flex items-center justify-between px-2 py-1">
           <button onClick={() => setActiveSession(null)} className="flex items-center gap-2 text-slate-500 hover:text-emerald-700 font-black uppercase text-[10px] tracking-widest">
             <ArrowLeft size={16}/> <span>KEMBALI</span>
           </button>
           <div className="text-right">
              <h3 className="text-[11px] font-black text-slate-800 uppercase leading-none">{activeSession.subject}</h3>
              <p className="text-[8px] font-bold text-emerald-600 uppercase tracking-widest mt-1">UNIT: {activeSession.class}</p>
           </div>
        </div>

        <div className="bg-emerald-900 text-white p-4 rounded-[1.5rem] shadow-md flex items-center justify-between">
           <div className="flex items-center gap-3">
              <UsersIcon size={18} className="text-emerald-400" />
              <div>
                 <p className="text-[10px] font-black uppercase leading-none">Total Santri: {tempRoster.length}</p>
                 <p className="text-[8px] font-bold text-emerald-100/60 uppercase mt-1 tracking-widest">Waktu: {activeSession.time}</p>
              </div>
           </div>
        </div>
        
        <div className="space-y-1">
           {tempRoster.map((student, idx) => (
             <div key={student.id} className="bg-white px-3 py-2.5 rounded-2xl border border-slate-100 shadow-sm flex flex-col gap-2">
                <div className="flex items-center justify-between gap-2">
                   <div className="flex items-center gap-2 min-w-0 flex-1">
                      <span className="text-[10px] font-black text-slate-300 w-5 shrink-0">{idx + 1}.</span>
                      <div className="min-w-0">
                         <h4 className="text-[11px] font-black text-slate-800 uppercase truncate leading-none mb-1">{student.name}</h4>
                         <p className="text-[8px] font-bold text-emerald-600 uppercase tracking-tight leading-none">
                           {student.formalClass} <span className="text-slate-200 mx-1">|</span> {student.nis}
                         </p>
                      </div>
                   </div>

                   <div className="flex gap-1 shrink-0">
                      {['H', 'S', 'I', 'T', 'A'].map((label) => {
                        const status = label === 'H' ? AttendanceStatus.H : 
                                       label === 'S' ? AttendanceStatus.S : 
                                       label === 'I' ? AttendanceStatus.I : 
                                       label === 'T' ? AttendanceStatus.T : AttendanceStatus.A;
                        const isActive = attendanceMap[student.id]?.status === status;
                        return (
                          <button 
                            key={label}
                            onClick={() => setAttendanceMap(p => ({ ...p, [student.id]: { ...p[student.id], status } }))}
                            className={`w-7 h-7 rounded-lg text-[10px] font-black transition-all border flex items-center justify-center ${isActive ? 'bg-[#064e3b] text-white border-[#064e3b] shadow-sm scale-110' : 'bg-slate-50 text-slate-400 border-slate-100'}`}
                          >
                            {label}
                          </button>
                        );
                      })}
                   </div>
                </div>

                {attendanceMap[student.id]?.status !== AttendanceStatus.H && (
                   <div className="animate-in slide-in-from-top-1 px-7">
                      <input 
                        type="text" 
                        placeholder={`Alasan ${attendanceMap[student.id]?.status}...`} 
                        className="w-full px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-[9px] font-bold outline-none focus:border-emerald-600"
                        value={attendanceMap[student.id]?.note || ''}
                        onChange={e => setAttendanceMap(p => ({ ...p, [student.id]: { ...p[student.id], note: e.target.value } }))}
                      />
                   </div>
                )}
             </div>
           ))}
        </div>
        
        <div className="fixed bottom-6 left-0 right-0 px-4 z-50">
           <button onClick={handleSaveAttendance} className="w-full max-w-md mx-auto py-5 bg-[#064e3b] text-white rounded-[2rem] font-black uppercase text-[11px] tracking-[0.2em] shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all">
              <Save size={18}/> SIMPAN ABSENSI
           </button>
        </div>
      </div>
    );
  }

  // UI DETAIL RIWAYAT (DRILL-DOWN)
  if (viewingHistoryDetail) {
    return (
      <div className="space-y-4 animate-in slide-in-from-right-10 duration-500 pb-32">
        <div className="flex items-center justify-between px-2 py-1">
           <button onClick={() => setSelectedHistorySessionKey(null)} className="flex items-center gap-2 text-slate-500 hover:text-emerald-700 font-black uppercase text-[10px] tracking-widest">
             <ArrowLeft size={16}/> <span>KEMBALI KE LIST</span>
           </button>
           <div className="text-right">
              <h3 className="text-[11px] font-black text-slate-800 uppercase leading-none">{viewingHistoryDetail.sessionType}</h3>
              <p className="text-[8px] font-bold text-emerald-600 uppercase tracking-widest mt-1">{targetHistoryDateStr}</p>
           </div>
        </div>

        <div className="bg-slate-100 p-4 rounded-[1.5rem] flex items-center justify-between border">
           <div className="flex items-center gap-3">
              <CheckCircle2 size={18} className="text-emerald-600" />
              <div>
                 <p className="text-[10px] font-black uppercase text-slate-800 leading-none">Unit: {viewingHistoryDetail.class}</p>
                 <p className="text-[8px] font-bold text-slate-400 uppercase mt-1">Selesai pada: {viewingHistoryDetail.time} WIB</p>
              </div>
           </div>
           <div className="text-right">
             <span className="text-[10px] font-black text-slate-800">{viewingHistoryDetail.count}</span>
             <p className="text-[7px] font-black text-slate-400 uppercase">Santri</p>
           </div>
        </div>

        <div className="space-y-1">
           {viewingHistoryDetail.records.sort((a,b) => {
             const nameA = props.students.find(s => s.id === a.studentId)?.name || '';
             const nameB = props.students.find(s => s.id === b.studentId)?.name || '';
             return nameA.localeCompare(nameB);
           }).map((record, idx) => {
             const student = props.students.find(s => s.id === record.studentId);
             return (
               <div key={record.id} className="bg-white px-3 py-2.5 rounded-2xl border border-slate-50 flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                     <div className="flex items-center gap-2 min-w-0 flex-1">
                        <span className="text-[10px] font-black text-slate-300 w-5 shrink-0">{idx + 1}.</span>
                        <div className="min-w-0">
                           <h4 className="text-[10px] font-black text-slate-800 uppercase truncate leading-none mb-0.5">{student?.name || 'Unknown'}</h4>
                           <p className="text-[8px] font-bold text-slate-400 uppercase leading-none">{student?.formalClass || '-'}</p>
                        </div>
                     </div>
                     <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black ${record.status === AttendanceStatus.H ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                        {getStatusLabel(record.status)}
                     </span>
                  </div>
                  {record.note && (
                    <p className="text-[8px] italic text-slate-400 px-7 leading-none">Ket: {record.note}</p>
                  )}
               </div>
             );
           })}
        </div>
      </div>
    );
  }

  // TAMPILAN UTAMA (TAB HARI INI & RIWAYAT)
  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-32">
      <div className="bg-[#064e3b] p-8 md:p-10 rounded-[2.5rem] md:rounded-[3rem] shadow-xl text-white text-center space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          <h2 className="text-xl md:text-2xl font-black uppercase tracking-tight leading-none relative z-10">Presensi KBM</h2>
          <div className="flex justify-center gap-1 bg-black/10 p-1.5 rounded-2xl max-w-xs mx-auto relative z-10">
             <button onClick={() => setActiveMainTab('today')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeMainTab === 'today' ? 'bg-white text-emerald-950 shadow-md' : 'text-white/40'}`}>HARI INI</button>
             <button onClick={() => setActiveMainTab('history')} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeMainTab === 'history' ? 'bg-white text-emerald-950 shadow-md' : 'text-white/40'}`}>RIWAYAT</button>
          </div>
      </div>

      {activeMainTab === 'today' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 px-1">
          {todaySchedules.map(s => (
            <button key={s.id} onClick={() => setActiveSession(s)} className="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-md transition-all text-left flex items-center justify-between group">
              <div className="min-w-0 pr-4">
                 <p className="text-[8px] font-black text-emerald-600 uppercase tracking-widest leading-none mb-2">{s.sessionType} • {s.time}</p>
                 <h3 className="text-[11px] font-black text-slate-800 uppercase truncate mb-1">{s.subject}</h3>
                 <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">Unit: {s.class}</p>
              </div>
              <div className="w-8 h-8 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 group-hover:bg-[#064e3b] group-hover:text-white transition-all shrink-0">
                <ChevronRight size={16}/>
              </div>
            </button>
          ))}
          {todaySchedules.length === 0 && (
            <div className="col-span-full py-20 text-center opacity-40 space-y-4">
               <AlertCircle size={32} className="mx-auto text-slate-300" />
               <p className="uppercase text-[9px] font-black tracking-[0.3em]">Jadwal Kosong / Selesai</p>
            </div>
          )}
        </div>
      )}

      {activeMainTab === 'history' && (
        <div className="space-y-4 px-1 animate-in slide-up duration-500">
           {/* Date Filter Ringkas */}
           <div className="bg-white p-4 rounded-[2rem] border shadow-sm space-y-3">
              <div className="flex gap-2">
                 <button 
                  onClick={() => setHistoryDateMode('today')}
                  className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${historyDateMode === 'today' ? 'bg-[#064e3b] text-white border-[#064e3b]' : 'bg-slate-50 text-slate-400 border-slate-100'}`}
                 >
                   HARI INI
                 </button>
                 <button 
                  onClick={() => setHistoryDateMode('custom')}
                  className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${historyDateMode === 'custom' ? 'bg-[#064e3b] text-white border-[#064e3b]' : 'bg-slate-50 text-slate-400 border-slate-100'}`}
                 >
                   PILIH TANGGAL
                 </button>
              </div>
              
              {historyDateMode === 'custom' && (
                <div className="relative animate-in slide-in-from-top-2">
                  <CalendarIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-600" size={16} />
                  <input 
                    type="date" 
                    value={historyCustomDate} 
                    onChange={e => setHistoryCustomDate(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 rounded-xl text-[11px] font-black uppercase border-none shadow-inner outline-none"
                  />
                </div>
              )}
           </div>

           {/* List History Grouped */}
           <div className="space-y-2">
              <div className="flex items-center gap-2 px-3 mb-2">
                 <Clock size={14} className="text-slate-300" />
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Daftar Sesi Terabsen ({targetHistoryDateStr})</p>
              </div>

              {historySessions.length > 0 ? historySessions.map(sess => (
                <button 
                  key={sess.key} 
                  onClick={() => setSelectedHistorySessionKey(sess.key)}
                  className="w-full bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm flex items-center justify-between group hover:shadow-md transition-all text-left"
                >
                  <div className="min-w-0 pr-4">
                     <p className="text-[8px] font-black text-emerald-600 uppercase tracking-widest mb-1.5">{sess.sessionType}</p>
                     <h3 className="text-[11px] font-black text-slate-800 uppercase truncate leading-none mb-2">Unit Kelas: {sess.class}</h3>
                     <div className="flex items-center gap-3">
                        <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Selesai: {sess.time}</span>
                        <span className="w-1 h-1 bg-slate-200 rounded-full"></span>
                        <span className="text-[8px] font-black text-emerald-600 uppercase">{sess.count} SANTRI</span>
                     </div>
                  </div>
                  <div className="w-8 h-8 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 group-hover:bg-[#064e3b] group-hover:text-white transition-all shrink-0">
                    <ChevronRight size={16}/>
                  </div>
                </button>
              )) : (
                <div className="py-20 text-center opacity-30 space-y-4">
                   <AlertCircle size={32} className="mx-auto text-slate-200" />
                   <p className="uppercase text-[9px] font-black tracking-[0.2em] leading-none">Belum ada riwayat absen<br/>pada tanggal ini</p>
                </div>
              )}
           </div>
        </div>
      )}
    </div>
  );
};

export default Attendance;
