
import React, { useState, useMemo } from 'react';
import { 
  AppData, UserRole, AttendanceStatus, PrayerStatus, 
  ViolationCategory, Student, AttendanceRecord, 
  PrayerRecord, TeacherAttendance, ReportItem 
} from './views/utils/types.ts';
import { 
  Download, Users, Calendar, Filter, Search, 
  ClipboardCheck, ShieldAlert, GraduationCap, Trophy, 
  Clock, CheckCircle2, ChevronDown, Lock, ArrowRight
} from 'lucide-react';
import { downloadCSV } from './views/csvExport.ts';

interface RekapLaporanProps {
  data: AppData;
  profile: { role: UserRole; email: string };
}

type Period = 'today' | 'week' | 'month' | 'semester' | 'custom';

const RekapLaporan: React.FC<RekapLaporanProps> = ({ data, profile }) => {
  const [activeTab, setActiveTab] = useState<'kbm' | 'pondok' | 'guru' | 'pelanggaran' | 'prestasi'>('kbm');
  const [period, setPeriod] = useState<Period>('month');
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [sessionFilter, setSessionFilter] = useState('Semua');
  const [classFilter, setClassFilter] = useState('Semua');
  const [searchTerm, setSearchTerm] = useState('');

  // 1. Logic Hak Akses Unduh (Whitelist Roles)
  const canDownload = useMemo(() => {
    const isAdmin = profile.email.toLowerCase().trim() === 'idarohmahasina@gmail.com';
    const allowedRoles = [
      UserRole.IDAROH, 
      UserRole.PENGASUH, 
      UserRole.MUSYRIF, 
      UserRole.OFFICER_PUTRA, 
      UserRole.OFFICER_PUTRI
    ];
    return isAdmin || allowedRoles.includes(profile.role);
  }, [profile]);

  // 2. Helper Matcher Tanggal Terintegrasi
  const isDateInRange = (dateStr: string) => {
    if (!dateStr) return false;
    // Format data kita adalah DD/MM/YYYY
    const [d, m, y] = dateStr.split('/').map(Number);
    const itemDate = new Date(y, m - 1, d);
    const now = new Date();
    
    if (period === 'today') return itemDate.toDateString() === now.toDateString();
    
    if (period === 'week') {
      const start = new Date();
      start.setDate(now.getDate() - 7);
      return itemDate >= start && itemDate <= now;
    }
    
    if (period === 'month') {
      return itemDate.getMonth() === now.getMonth() && itemDate.getFullYear() === now.getFullYear();
    }
    
    if (period === 'semester') {
      // Semester I (Ganjil): Jul-Des, Semester II (Genap): Jan-Jun
      const month = itemDate.getMonth();
      const nowMonth = now.getMonth();
      const isFirstHalf = month >= 6 && month <= 11; // Jul-Des
      const isNowFirstHalf = nowMonth >= 6 && nowMonth <= 11;
      return isFirstHalf === isNowFirstHalf && itemDate.getFullYear() === now.getFullYear();
    }
    
    if (period === 'custom') {
      const s = new Date(startDate);
      const e = new Date(endDate);
      // Normalize time to compare only dates
      s.setHours(0,0,0,0);
      e.setHours(23,59,59,999);
      return itemDate >= s && itemDate <= e;
    }
    
    return true;
  };

  // 3. Pengolahan Data Berdasarkan Tab Aktif
  const processedData = useMemo(() => {
    const sTerm = searchTerm.toLowerCase();

    // --- REKAP KBM ---
    if (activeTab === 'kbm') {
      return data.students
        .filter(s => (classFilter === 'Semua' || s.formalClass === classFilter) && s.name.toLowerCase().includes(sTerm))
        .map(s => {
          const logs = data.attendance.filter(a => a.studentId === s.id && isDateInRange(a.date) && (sessionFilter === 'Semua' || a.sessionType === sessionFilter));
          const counts = {
            H: logs.filter(l => l.status === AttendanceStatus.H).length,
            S: logs.filter(l => l.status === AttendanceStatus.S).length,
            I: logs.filter(l => l.status === AttendanceStatus.I).length,
            T: logs.filter(l => l.status === AttendanceStatus.T).length,
            A: logs.filter(l => l.status === AttendanceStatus.A).length,
          };
          const total = Object.values(counts).reduce((a, b) => a + b, 0);
          return { 
            Nama: s.name, NIS: s.nis, Kelas: s.formalClass, ...counts, 
            Total_Log: total, Persen_Hadir: total > 0 ? Math.round(((counts.H + counts.T) / total) * 100) + '%' : '0%' 
          };
        });
    }

    // --- REKAP PONDOK ---
    if (activeTab === 'pondok') {
      return data.students
        .filter(s => (classFilter === 'Semua' || s.formalClass === classFilter) && s.name.toLowerCase().includes(sTerm))
        .map(s => {
          const logs = data.prayerAttendance.filter(p => p.studentId === s.id && isDateInRange(p.date) && (sessionFilter === 'Semua' || p.prayerTime === sessionFilter));
          const counts = {
            Jamaah: logs.filter(l => l.status === PrayerStatus.JAMAAH).length,
            Udzur: logs.filter(l => l.status === PrayerStatus.UDZUR).length,
            Sakit: logs.filter(l => l.status === PrayerStatus.SAKIT).length,
            Izin: logs.filter(l => l.status === PrayerStatus.IZIN).length,
            Terlambat: logs.filter(l => l.status === PrayerStatus.TERLAMBAT).length,
            Alpha: logs.filter(l => l.status === PrayerStatus.ALPHA).length,
          };
          const total = Object.values(counts).reduce((a, b) => a + b, 0);
          return { 
            Nama: s.name, NIS: s.nis, Kelas: s.formalClass, ...counts, 
            Total_Log: total, Persen_Jamaah: total > 0 ? Math.round((counts.Jamaah / total) * 100) + '%' : '0%' 
          };
        });
    }

    // --- REKAP GURU ---
    if (activeTab === 'guru') {
      return data.teachers
        .filter(t => t.name.toLowerCase().includes(sTerm))
        .map(t => {
          const logs = data.teacherAttendance.filter(ta => ta.teacherEmail === t.email && isDateInRange(ta.date));
          const counts = {
            Hadir: logs.filter(l => l.status === AttendanceStatus.H).length,
            Sakit: logs.filter(l => l.status === AttendanceStatus.S).length,
            Izin: logs.filter(l => l.status === AttendanceStatus.I).length,
            Libur: logs.filter(l => l.status === AttendanceStatus.LIBUR).length,
          };
          return { Nama: t.name, Email: t.email, Mapel: t.subject, ...counts, Total_Log: logs.length };
        });
    }

    // --- REKAP PELANGGARAN / PRESTASI ---
    if (activeTab === 'pelanggaran' || activeTab === 'prestasi') {
      const type = activeTab === 'pelanggaran' ? 'Violation' : 'Achievement';
      return data.students
        .filter(s => (classFilter === 'Semua' || s.formalClass === classFilter) && s.name.toLowerCase().includes(sTerm))
        .map(s => {
          const logs = data.reports.filter(r => r.studentId === s.id && r.type === type && isDateInRange(r.date) && (sessionFilter === 'Semua' || r.category === sessionFilter));
          const points = logs.reduce((acc, curr) => acc + curr.points, 0);
          return { 
            Nama: s.name, NIS: s.nis, Kelas: s.formalClass, 
            Frekuensi: logs.length, Total_Poin: points, Terakhir: logs[0]?.date || '-' 
          };
        }).filter(item => item.Frekuensi > 0);
    }

    return [];
  }, [activeTab, period, startDate, endDate, sessionFilter, classFilter, searchTerm, data]);

  const handleDownload = () => {
    if (!canDownload) {
      alert("Maaf, akun Anda tidak memiliki hak akses untuk mengunduh rekapitulasi data.");
      return;
    }
    const fileName = `Rekap_${activeTab.toUpperCase()}_${period}_${new Date().toLocaleDateString()}`;
    downloadCSV(processedData, fileName);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-32 max-w-7xl mx-auto px-1">
      {/* HEADER VISUAL */}
      <div className="bg-[#064e3b] p-8 md:p-12 rounded-[2.5rem] md:rounded-[3.5rem] shadow-xl text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
           <div className="text-center md:text-left space-y-2">
              <h2 className="text-2xl md:text-4xl font-black uppercase tracking-tight leading-none">Pusat Rekapitulasi</h2>
              <p className="text-emerald-400 text-[9px] md:text-[11px] font-black uppercase tracking-[0.4em] leading-none">Audit & Laporan Komprehensif Mahasina</p>
           </div>
           <div className="bg-white/10 backdrop-blur-md p-5 rounded-3xl border border-white/10 text-center">
              <p className="text-[9px] font-black uppercase tracking-widest text-emerald-300 mb-1">Data Terproses</p>
              <h4 className="text-2xl md:text-4xl font-black">{processedData.length} Baris</h4>
           </div>
        </div>
      </div>

      {/* TABS MENU */}
      <div className="bg-white p-2 rounded-3xl shadow-xl flex gap-1 border border-slate-100 overflow-x-auto no-scrollbar">
        {[
          { id: 'kbm', label: 'ABSEN KBM', icon: <ClipboardCheck size={14}/> },
          { id: 'pondok', label: 'ABSEN PONDOK', icon: <Clock size={14}/> },
          { id: 'guru', label: 'ABSEN GURU', icon: <GraduationCap size={14}/> },
          { id: 'pelanggaran', label: 'PELANGGARAN', icon: <ShieldAlert size={14}/> },
          { id: 'prestasi', label: 'PRESTASI', icon: <Trophy size={14}/> },
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => { setActiveTab(tab.id as any); setSessionFilter('Semua'); }}
            className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 rounded-2xl whitespace-nowrap text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab.id ? 'bg-[#064e3b] text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* FILTER PANEL */}
      <div className="bg-white p-6 md:p-10 rounded-[2.5rem] md:rounded-[4rem] border shadow-sm space-y-8">
        <div className="flex items-center gap-3 border-b pb-4">
           <Filter size={18} className="text-emerald-600" />
           <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-800">Konfigurasi Rekapitulasi</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           {/* Row 1 */}
           <div className="space-y-1.5">
              <p className="text-[8px] font-black text-slate-400 uppercase ml-2">Jangka Waktu</p>
              <select value={period} onChange={e => setPeriod(e.target.value as Period)} className="w-full p-4 bg-slate-50 border rounded-2xl text-[10px] font-black uppercase shadow-inner outline-none appearance-none cursor-pointer">
                 <option value="today">HARI INI</option>
                 <option value="week">MINGGU INI</option>
                 <option value="month">BULAN INI</option>
                 <option value="semester">SEMESTER INI</option>
                 <option value="custom">RENTANG TANGGAL (PILIH)</option>
              </select>
           </div>

           <div className="space-y-1.5">
              <p className="text-[8px] font-black text-slate-400 uppercase ml-2">Sesi / Kategori</p>
              <select value={sessionFilter} onChange={e => setSessionFilter(e.target.value)} className="w-full p-4 bg-slate-50 border rounded-2xl text-[10px] font-black uppercase shadow-inner outline-none">
                 <option value="Semua">SEMUA SESI</option>
                 {activeTab === 'kbm' && ['Madrasah', 'Al-Quran', 'Kitab Kuning', 'Tahfidz', 'Bahasa'].map(s => <option key={s} value={s}>{s}</option>)}
                 {activeTab === 'pondok' && ['Subuh', 'Dhuha', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya', 'Khataman Al-Quran', 'Lalaran Ahad Malam', 'Senam Pagi'].map(s => <option key={s} value={s}>{s}</option>)}
                 {(activeTab === 'pelanggaran' || activeTab === 'prestasi') && Object.values(ViolationCategory).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
           </div>

           <div className="space-y-1.5">
              <p className="text-[8px] font-black text-slate-400 uppercase ml-2">Unit Kelas Formal</p>
              <select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full p-4 bg-slate-50 border rounded-2xl text-[10px] font-black uppercase shadow-inner outline-none">
                 <option value="Semua">SEMUA KELAS</option>
                 {Array.from(new Set(data.students.map(s => s.formalClass))).sort().map(c => <option key={c} value={c}>{c}</option>)}
              </select>
           </div>

           {/* Row 2 (Date Range - Conditional) */}
           {period === 'custom' && (
             <div className="lg:col-span-3 grid grid-cols-2 gap-4 animate-in slide-in-from-top-2">
                <div className="space-y-1.5">
                   <p className="text-[8px] font-black text-slate-400 uppercase ml-2">Mulai Tanggal</p>
                   <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full p-4 bg-slate-50 border rounded-2xl text-[10px] font-black outline-none shadow-inner" />
                </div>
                <div className="space-y-1.5">
                   <p className="text-[8px] font-black text-slate-400 uppercase ml-2">Sampai Tanggal</p>
                   <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full p-4 bg-slate-50 border rounded-2xl text-[10px] font-black outline-none shadow-inner" />
                </div>
             </div>
           )}

           {/* Search & Download */}
           <div className="lg:col-span-2 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
              <input type="text" placeholder="Cari nama santri..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-12 pr-4 py-4 bg-slate-50 rounded-2xl text-[11px] font-bold outline-none shadow-inner focus:border-emerald-600 transition-all" />
           </div>
           <button 
            onClick={handleDownload}
            className={`w-full py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl active:scale-95 transition-all ${canDownload ? 'bg-[#064e3b] text-white hover:bg-emerald-800' : 'bg-slate-100 text-slate-400 cursor-not-allowed'}`}
           >
              {canDownload ? <Download size={18}/> : <Lock size={18}/>}
              {canDownload ? 'UNDUH REKAP (.CSV)' : 'DOWNLOAD TERKUNCI'}
           </button>
        </div>
      </div>

      {/* REKAP TABLE */}
      <div className="bg-white rounded-[3rem] md:rounded-[5rem] border shadow-2xl overflow-hidden min-h-[500px]">
        <div className="overflow-x-auto no-scrollbar">
           {processedData.length > 0 ? (
             <table className="w-full text-left min-w-[900px]">
               <thead className="bg-slate-50 border-b">
                 <tr className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">
                   <th className="p-8">IDENTITAS</th>
                   {activeTab === 'kbm' && <><th className="p-8 text-center">H</th><th className="p-8 text-center">S</th><th className="p-8 text-center">I</th><th className="p-8 text-center">T</th><th className="p-8 text-center">A</th><th className="p-8 text-center">% AKTIF</th></>}
                   {activeTab === 'pondok' && <><th className="p-8 text-center">JMH</th><th className="p-8 text-center">UDZ</th><th className="p-8 text-center">SKT</th><th className="p-8 text-center">IZN</th><th className="p-8 text-center">TLT</th><th className="p-8 text-center">ALP</th><th className="p-8 text-center">% JAMAAH</th></>}
                   {activeTab === 'guru' && <><th className="p-8 text-center">HADIR</th><th className="p-8 text-center">SAKIT</th><th className="p-8 text-center">IZIN</th><th className="p-8 text-center">LIBUR</th><th className="p-8 text-center">TOTAL</th></>}
                   {(activeTab === 'pelanggaran' || activeTab === 'prestasi') && <><th className="p-8 text-center">FREKUENSI</th><th className="p-8 text-center">TOTAL POIN</th><th className="p-8 text-center">TERAKHIR</th></>}
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-50 text-[12px] font-bold">
                 {processedData.map((row: any, i) => (
                   <tr key={i} className="hover:bg-slate-50 transition-all">
                     <td className="p-8 text-left">
                        <p className="font-black text-slate-800 uppercase leading-none mb-2">{row.Nama}</p>
                        <p className="text-[10px] font-black text-slate-400 uppercase leading-none tracking-widest">{row.NIS || row.Email} {row.Kelas ? `• ${row.Kelas}` : ''}</p>
                     </td>
                     {activeTab === 'kbm' && (
                       <>
                        <td className="p-8 text-center text-emerald-600">{row.H}</td>
                        <td className="p-8 text-center text-blue-500">{row.S}</td>
                        <td className="p-8 text-center text-amber-500">{row.I}</td>
                        <td className="p-8 text-center text-slate-500">{row.T}</td>
                        <td className="p-8 text-center text-red-500">{row.A}</td>
                        <td className="p-8 text-center"><span className="px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-lg font-black border border-emerald-100">{row.Persen_Hadir}</span></td>
                       </>
                     )}
                     {activeTab === 'pondok' && (
                       <>
                        <td className="p-8 text-center text-emerald-600">{row.Jamaah}</td>
                        <td className="p-8 text-center text-indigo-500">{row.Udzur}</td>
                        <td className="p-8 text-center text-blue-500">{row.Sakit}</td>
                        <td className="p-8 text-center text-amber-500">{row.Izin}</td>
                        <td className="p-8 text-center text-slate-500">{row.Terlambat}</td>
                        <td className="p-8 text-center text-red-500">{row.Alpha}</td>
                        <td className="p-8 text-center"><span className="px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-lg font-black border border-emerald-100">{row.Persen_Jamaah}</span></td>
                       </>
                     )}
                     {activeTab === 'guru' && (
                       <>
                        <td className="p-8 text-center text-emerald-600">{row.Hadir}</td>
                        <td className="p-8 text-center text-blue-500">{row.Sakit}</td>
                        <td className="p-8 text-center text-amber-500">{row.Izin}</td>
                        <td className="p-8 text-center text-slate-400">{row.Libur}</td>
                        <td className="p-8 text-center font-black text-slate-800">{row.Total_Log}</td>
                       </>
                     )}
                     {(activeTab === 'pelanggaran' || activeTab === 'prestasi') && (
                        <>
                         <td className="p-8 text-center">{row.Frekuensi}x</td>
                         <td className="p-8 text-center font-black text-red-600">{row.Total_Poin} POIN</td>
                         <td className="p-8 text-center text-slate-400 text-[10px]">{row.Terakhir}</td>
                        </>
                     )}
                   </tr>
                 ))}
               </tbody>
             </table>
           ) : (
             <div className="py-40 text-center opacity-20 space-y-6">
                <Users size={64} className="mx-auto" />
                <p className="text-[11px] font-black uppercase tracking-[0.4em]">Belum Ada Laporan Rekapitulasi</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default RekapLaporan;
