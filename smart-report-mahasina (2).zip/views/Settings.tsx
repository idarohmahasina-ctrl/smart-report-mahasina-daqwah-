
import React, { useState, useEffect } from 'react';
import { UserRole, UserProfile, AcademicConfig, Student, Schedule } from './utils/types.ts';
import { 
  getAllUsers, registerUser, deleteUser, clearAppData 
} from '../services/dataService.ts';
import { 
  User as UserIcon, Users, RefreshCw, LogOut, Trash2, 
  Check, Calendar, BookOpen, Info, AlertTriangle, Ban, 
  CloudLightning, Settings as SettingsIcon, ShieldAlert, 
  Zap, X, Save, ChevronDown, ChevronRight, ToggleLeft, ToggleRight,
  Coffee, GraduationCap
} from 'lucide-react';

interface SettingsProps {
  userEmail: string;
  academicConfig: AcademicConfig;
  onUpdateAcademic: (c: AcademicConfig) => void;
  students: Student[];
  schedules: Schedule[];
  availableClasses: string[];
}

const Settings: React.FC<SettingsProps> = ({ 
  userEmail, academicConfig, onUpdateAcademic, students, schedules 
}) => {
  const [expandedId, setExpandedId] = useState<string | null>('profile');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const isAdmin = userEmail.toLowerCase().trim() === 'idarohmahasina@gmail.com';

  const [schoolYear, setSchoolYear] = useState(academicConfig?.schoolYear || '2024/2025');
  const [semester, setSemester] = useState(academicConfig?.semester || 'Semester I');
  
  // Local state for holiday management
  const [excludedSessions, setExcludedSessions] = useState<Record<string, boolean>>(academicConfig?.excludedSessions || {});
  const [sessionClassExclusions, setSessionClassExclusions] = useState<Record<string, Record<string, boolean>>>(academicConfig?.sessionClassExclusions || {});

  const [resetStep, setResetStep] = useState(0);

  useEffect(() => {
    if (isAdmin) {
      loadUsers();
    }
  }, [isAdmin]);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const allUsers = await getAllUsers();
      setUsers(allUsers);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateRole = async (email: string, role: UserRole) => {
    const user = users.find(u => u.email === email);
    if (user) {
      await registerUser({ ...user, role });
      loadUsers();
      alert("Role diperbarui");
    }
  };

  const handleBlockUser = async (email: string, blocked: boolean) => {
    const user = users.find(u => u.email === email);
    if (user) {
      await registerUser({ ...user, isBlocked: blocked });
      loadUsers();
      alert(blocked ? "Diblokir" : "Aktif");
    }
  };

  const handleSaveAcademic = () => {
    onUpdateAcademic({ 
      ...academicConfig, 
      schoolYear, 
      semester, 
      excludedSessions, 
      sessionClassExclusions 
    });
    alert("Konfigurasi sistem berhasil disimpan!");
  };

  const toggleSessionExclusion = (sessionName: string) => {
    setExcludedSessions(prev => ({
      ...prev,
      [sessionName]: !prev[sessionName]
    }));
  };

  const toggleClassExclusion = (sessionName: string, className: string) => {
    setSessionClassExclusions(prev => {
      const sessionData = prev[sessionName] || {};
      return {
        ...prev,
        [sessionName]: {
          ...sessionData,
          [className]: !sessionData[className]
        }
      };
    });
  };

  // Fix: Explicitly type Array.from and new Set to avoid unknown inference
  const sessionTypes: string[] = Array.from<string>(new Set(schedules.map(s => s.sessionType))).sort();
  const allClasses: string[] = Array.from<string>(new Set(students.map(s => s.formalClass))).sort();

  const menuItems = [
    { id: 'profile', label: 'Profil Akun', desc: 'Identitas user saat ini', icon: <UserIcon size={18}/>, admin: false, color: 'emerald' },
    { id: 'users', label: 'Petugas', desc: 'Hak akses & Role', icon: <Users size={18}/>, admin: true, color: 'indigo' },
    { id: 'libur', label: 'Manajemen Libur', desc: 'Atur Sesi & Kelas Libur', icon: <Coffee size={18}/>, admin: true, color: 'emerald' },
    { id: 'semester', label: 'Konfigurasi', desc: 'Semester & Tahun', icon: <BookOpen size={18}/>, admin: true, color: 'amber' },
    { id: 'reset', label: 'Reset Data', desc: 'Hapus log sistem', icon: <Trash2 size={18}/>, admin: true, color: 'red' },
  ];

  const visibleMenus = isAdmin ? menuItems : menuItems.filter(m => !m.admin);

  return (
    <div className="space-y-4 md:space-y-6 animate-in fade-in duration-500 pb-32 max-w-4xl mx-auto px-1">
      {/* Banner */}
      <div className="bg-[#064e3b] p-6 md:p-10 rounded-[1.5rem] md:rounded-[3.5rem] shadow-xl relative overflow-hidden text-white border-b-4 border-emerald-500">
        <div className="relative z-10 flex flex-col items-center md:flex-row md:justify-start gap-4 md:gap-5 text-center md:text-left">
          <div className="w-12 h-12 md:w-14 md:h-14 bg-white/10 rounded-xl md:rounded-2xl flex items-center justify-center border border-white/20 shrink-0">
            <SettingsIcon size={24} className="md:w-7 md:h-7" />
          </div>
          <div className="min-w-0">
            <h2 className="text-lg md:text-2xl font-black uppercase tracking-tight leading-none mb-1.5 md:mb-2">Pengaturan</h2>
            <p className="text-emerald-400 text-[8px] md:text-[10px] font-black uppercase tracking-[0.3em] leading-none">Smart Report Mahasina</p>
          </div>
        </div>
      </div>

      {/* Accordion List */}
      <div className="space-y-2">
        {visibleMenus.map((item) => (
          <div key={item.id} className="bg-white rounded-[1.25rem] md:rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden transition-all">
            <button 
              onClick={() => setExpandedId(expandedId === item.id ? null : item.id)}
              className={`w-full flex items-center justify-between p-4 md:p-8 transition-colors ${expandedId === item.id ? 'bg-slate-50/50' : 'hover:bg-slate-50'}`}
            >
              <div className="flex items-center gap-3 md:gap-4 text-left min-w-0">
                <div className={`w-9 h-9 md:w-10 md:h-10 bg-${item.color}-50 text-${item.color}-600 rounded-lg md:rounded-xl flex items-center justify-center shrink-0`}>
                  {item.icon}
                </div>
                <div className="min-w-0">
                  <h3 className="text-[11px] md:text-xs font-black text-slate-800 uppercase tracking-tight leading-none mb-1 md:mb-1.5 truncate">{item.label}</h3>
                  <p className="text-[7px] md:text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none truncate">{item.desc}</p>
                </div>
              </div>
              <ChevronRight size={14} className={`text-slate-300 transition-transform shrink-0 ${expandedId === item.id ? 'rotate-90' : ''}`} />
            </button>

            {expandedId === item.id && (
              <div className="px-4 pb-6 md:px-12 md:pb-12 pt-1 animate-in slide-in-from-top-2 duration-300 border-t border-slate-50">
                {item.id === 'profile' && (
                  <div className="space-y-4 pt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-3">
                      <div className="p-3 md:p-4 bg-slate-50 rounded-xl md:rounded-2xl">
                        <p className="text-[7px] md:text-[8px] font-black uppercase text-slate-400 leading-none mb-2">Email Akun</p>
                        <p className="text-[10px] md:text-[11px] font-black text-slate-800 truncate leading-none">{userEmail}</p>
                      </div>
                      <div className="p-3 md:p-4 bg-slate-50 rounded-xl md:rounded-2xl">
                        <p className="text-[7px] md:text-[8px] font-black uppercase text-slate-400 leading-none mb-2">Status Role</p>
                        <p className="text-[10px] md:text-[11px] font-black text-slate-800 uppercase leading-none truncate">{isAdmin ? 'Admin Utama' : 'Petugas'}</p>
                      </div>
                    </div>
                    <button onClick={() => { clearAppData(); window.location.reload(); }} className="w-full py-3.5 md:py-4 bg-red-50 text-red-600 rounded-xl md:rounded-2xl font-black uppercase text-[8px] md:text-[9px] tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all">
                      <LogOut size={16}/> Keluar dari Aplikasi
                    </button>
                  </div>
                )}

                {item.id === 'users' && isAdmin && (
                  <div className="space-y-3 pt-4">
                    <div className="overflow-x-auto border border-slate-100 rounded-xl no-scrollbar min-h-[150px]">
                      <table className="w-full text-left min-w-[450px]">
                        <thead className="bg-slate-50 text-[7px] md:text-[8px] font-black text-slate-400 uppercase tracking-widest border-b">
                          <tr><th className="p-3">User</th><th className="p-3">Role</th><th className="p-3 text-center">Aksi</th></tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50 text-[9px] md:text-[10px]">
                          {users.map(u => (
                            <tr key={u.email} className="hover:bg-slate-50/50">
                              <td className="p-3 font-black uppercase leading-tight">
                                {u.fullName}<br/><span className="text-[7px] md:text-[8px] text-slate-400 normal-case font-bold">{u.email}</span>
                              </td>
                              <td className="p-3">
                                <select value={u.role} onChange={e => handleUpdateRole(u.email, e.target.value as UserRole)} className="bg-white p-1.5 md:p-2 rounded-lg font-black text-[8px] md:text-[9px] uppercase border border-slate-100 outline-none shadow-sm cursor-pointer leading-tight">
                                  {Object.values(UserRole).map(r => <option key={r} value={r}>{r}</option>)}
                                </select>
                              </td>
                              <td className="p-3">
                                <div className="flex justify-center gap-1.5">
                                   <button onClick={() => handleBlockUser(u.email, !u.isBlocked)} className={`p-2 rounded-lg border shadow-sm transition-all ${u.isBlocked ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>{u.isBlocked ? <Check size={14}/> : <Ban size={14}/>}</button>
                                   <button onClick={() => { if(confirm("Hapus petugas ini secara permanen?")) deleteUser(u.email).then(loadUsers); }} className="p-2 bg-red-50 text-red-600 rounded-lg border border-red-100 shadow-sm"><Trash2 size={14}/></button>
                                </div>
                              </td>
                            </tr>
                          ))}
                          {users.length === 0 && (
                            <tr><td colSpan={3} className="py-10 text-center text-[9px] font-black text-slate-300 uppercase italic">Memuat data user...</td></tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {item.id === 'libur' && isAdmin && (
                  <div className="space-y-8 pt-6">
                    {/* Sesi Libur Global */}
                    <div className="space-y-4">
                       <div className="flex items-center gap-2 mb-2">
                          <Coffee size={16} className="text-emerald-600" />
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-800">Libur Sesi Global</h4>
                       </div>
                       <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          {sessionTypes.map(sess => (
                            <button 
                              key={sess} 
                              onClick={() => toggleSessionExclusion(sess)}
                              className={`p-4 rounded-2xl border flex items-center justify-between group transition-all ${excludedSessions[sess] ? 'bg-red-50 border-red-200 text-red-700' : 'bg-slate-50 border-slate-100 text-slate-400'}`}
                            >
                               <span className="text-[9px] font-black uppercase tracking-tight">{sess}</span>
                               {excludedSessions[sess] ? <ToggleRight className="text-red-500" /> : <ToggleLeft className="text-slate-300" />}
                            </button>
                          ))}
                       </div>
                    </div>

                    {/* Libur Unit Kelas Spesifik */}
                    <div className="space-y-4 border-t pt-6">
                       <div className="flex items-center gap-2 mb-2">
                          <GraduationCap size={16} className="text-emerald-600" />
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-800">Libur Per Unit Kelas</h4>
                       </div>
                       <div className="space-y-6">
                          {sessionTypes.filter(s => !excludedSessions[s]).map(sess => (
                            <div key={sess} className="space-y-3 p-4 bg-slate-50/50 rounded-3xl border border-slate-100">
                               <p className="text-[8px] font-black uppercase text-emerald-600 tracking-[0.2em]">{sess}</p>
                               <div className="flex flex-wrap gap-2">
                                  {allClasses.map(cls => (
                                    <button 
                                      key={cls} 
                                      onClick={() => toggleClassExclusion(sess, cls)}
                                      className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase transition-all border ${sessionClassExclusions[sess]?.[cls] ? 'bg-amber-100 text-amber-700 border-amber-200 shadow-sm' : 'bg-white text-slate-400 border-slate-100 hover:border-emerald-200'}`}
                                    >
                                       {cls}
                                    </button>
                                  ))}
                               </div>
                            </div>
                          ))}
                          {sessionTypes.filter(s => !excludedSessions[s]).length === 0 && (
                            <p className="py-10 text-center text-[9px] font-bold text-slate-400 italic">Semua sesi sedang dalam status libur global.</p>
                          )}
                       </div>
                    </div>

                    <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-center gap-3 text-amber-700">
                       <AlertTriangle size={18} className="shrink-0" />
                       <p className="text-[8px] font-bold uppercase leading-tight">Pengaturan ini akan menonaktifkan input absensi pada menu santri dan guru untuk kategori yang dipilih.</p>
                    </div>

                    <button onClick={handleSaveAcademic} className="w-full py-4 bg-[#064e3b] text-white rounded-[2rem] font-black uppercase text-[10px] tracking-widest shadow-xl flex items-center justify-center gap-3">
                       <Save size={18}/> Update Status Libur
                    </button>
                  </div>
                )}

                {item.id === 'semester' && isAdmin && (
                  <div className="space-y-4 pt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[7px] md:text-[8px] font-black text-slate-400 uppercase ml-1 leading-none">Tahun Ajaran</label>
                        <input type="text" value={schoolYear} onChange={e => setSchoolYear(e.target.value)} className="w-full p-2.5 md:p-3 bg-slate-50 rounded-lg md:rounded-xl text-[9px] md:text-[10px] font-black outline-none border border-slate-100 shadow-inner" />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[7px] md:text-[8px] font-black text-slate-400 uppercase ml-1 leading-none">Semester Aktif</label>
                        <select value={semester} onChange={e => setSemester(e.target.value)} className="w-full p-2.5 md:p-3 bg-slate-50 rounded-lg md:rounded-xl text-[9px] md:text-[10px] font-black uppercase outline-none border border-slate-100 shadow-inner appearance-none cursor-pointer leading-tight">
                          <option value="Semester I">Ganjil (I)</option><option value="Semester II">Genap (II)</option>
                        </select>
                      </div>
                    </div>
                    <button onClick={handleSaveAcademic} className="w-full py-3.5 md:py-4 bg-emerald-950 text-white rounded-xl md:rounded-2xl font-black uppercase text-[8px] md:text-[9px] tracking-widest shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 mt-2">
                      <Save size={16}/> Simpan Konfigurasi
                    </button>
                  </div>
                )}

                {item.id === 'reset' && isAdmin && (
                  <div className="pt-4 text-center space-y-4">
                    <div className="p-3 md:p-4 bg-red-50 rounded-xl md:rounded-2xl border border-red-100 flex items-center gap-3 text-red-600 text-left">
                       <ShieldAlert size={20} className="shrink-0" />
                       <p className="text-[8px] md:text-[9px] font-black uppercase leading-tight">Berbahaya: Tindakan ini menghapus data absen selamanya. Pastikan Anda sudah mengekspor rekapitulasi data.</p>
                    </div>
                    <button onClick={() => setResetStep(1)} className="w-full py-3.5 md:py-4 bg-red-600 text-white rounded-xl md:rounded-2xl font-black uppercase text-[9px] md:text-[10px] tracking-widest shadow-xl active:scale-95 transition-all">Format Sistem / Reset Data</button>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Settings;
