import React, { useState } from 'react';
import { UserRole, UserProfile } from './utils/types.ts';
import { APP_LOGO } from '../services/components/constants.tsx';
import { getUserByEmail, registerUser, setActiveSession } from '../services/dataService.ts';
import { Mail, Phone, RefreshCw, AlertCircle, Zap, ShieldCheck, ArrowLeft, UserCircle } from 'lucide-react';

interface RegistrationProps {
  onComplete: (profile: UserProfile) => void;
}

const Registration: React.FC<RegistrationProps> = ({ onComplete }) => {
  const [step, setStep] = useState<'email' | 'details'>('email');
  const [email, setEmail] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    role: UserRole.GURU
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCheckEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.toLowerCase().trim();
    if (!cleanEmail) return;

    setLoading(true);
    setError(null);
    try {
      const existingUser = await getUserByEmail(cleanEmail);
      if (existingUser) {
        setActiveSession(existingUser);
        onComplete(existingUser);
      } else {
        setStep('details');
        setLoading(false);
      }
    } catch (err) {
      setError("Email tidak ditemukan atau error sinkronisasi.");
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.phone) {
      setError("Mohon lengkapi profil Anda.");
      return;
    }

    setLoading(true);
    const cleanEmail = email.toLowerCase().trim();
    const newProfile: UserProfile = {
      id: `u-${Date.now()}`,
      fullName: formData.fullName,
      email: cleanEmail,
      phone: formData.phone,
      role: formData.role,
      isBlocked: false
    };

    try {
      await registerUser(newProfile);
      setActiveSession(newProfile);
      onComplete(newProfile);
    } catch (err) {
      setError("Gagal mendaftar. Coba lagi.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#064e3b] p-4 md:p-6 font-sans overflow-y-auto">
      <div className="bg-white w-full max-w-sm md:max-w-md rounded-[2.5rem] md:rounded-[4rem] shadow-2xl p-8 md:p-12 space-y-6 md:space-y-8 animate-in fade-in zoom-in-95 duration-500">
        <div className="text-center space-y-3">
           <img src={APP_LOGO} className="w-14 h-14 md:w-20 md:h-20 mx-auto bg-emerald-50 p-2 md:p-3 rounded-2xl md:rounded-3xl shadow-inner" alt="Logo" />
           <div className="space-y-1">
              <h1 className="text-xl md:text-2xl font-black text-slate-800 uppercase tracking-tighter leading-none mb-1 md:mb-1.5">Smart Report</h1>
              <p className="text-[7px] md:text-[10px] font-black text-emerald-600 uppercase tracking-[0.2em] md:tracking-[0.3em] leading-none">Mahasina Darul Qur'an</p>
           </div>
        </div>

        {error && (
          <div className="p-3 md:p-4 bg-red-50 text-red-600 rounded-xl md:rounded-2xl flex items-center gap-3 border border-red-100 text-[9px] md:text-[10px] font-black uppercase leading-tight">
             <AlertCircle size={16} className="shrink-0" />
             <p>{error}</p>
          </div>
        )}

        {step === 'email' ? (
          <div className="space-y-6">
            <form onSubmit={handleCheckEmail} className="space-y-5 md:space-y-6">
               <div className="space-y-1.5 md:space-y-2">
                  <label className="text-[8px] md:text-[9px] font-black uppercase tracking-widest text-slate-400 ml-2 leading-none">Alamat Email</label>
                  <div className="relative">
                    <Mail className="absolute left-4 md:left-5 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      required 
                      type="email" 
                      value={email} 
                      onChange={e => setEmail(e.target.value)} 
                      className="w-full pl-12 md:pl-14 pr-4 md:pr-6 py-4 md:py-5 bg-slate-50 rounded-2xl md:rounded-[2rem] outline-none font-bold text-xs md:text-sm border-2 border-transparent focus:border-emerald-600 transition-all shadow-inner" 
                      placeholder="ustadz@gmail.com" 
                    />
                  </div>
               </div>
               <button type="submit" disabled={loading || !email} className="w-full bg-[#064e3b] text-white font-black py-4 md:py-5 rounded-[1.5rem] md:rounded-[2.5rem] shadow-xl flex items-center justify-center gap-2 md:gap-3 uppercase text-[9px] md:text-[10px] tracking-widest hover:bg-emerald-800 active:scale-95 transition-all">
                 {loading ? <RefreshCw className="animate-spin" size={18}/> : <Zap size={18}/>} Lanjutkan
               </button>
            </form>
          </div>
        ) : (
          <div className="space-y-5 md:space-y-6">
            <div className="flex items-center gap-3 md:gap-4 border-b border-slate-50 pb-4">
              <button type="button" onClick={() => setStep('email')} className="p-2 text-slate-300 hover:text-emerald-600 transition-colors">
                <ArrowLeft size={18} />
              </button>
              <div className="min-w-0">
                <h2 className="text-[10px] md:text-[11px] font-black uppercase text-slate-800 tracking-tight leading-none mb-1">Daftar Akun Baru</h2>
                <p className="text-[7px] md:text-[8px] font-bold text-slate-400 uppercase truncate leading-none">{email}</p>
              </div>
            </div>

            <form onSubmit={handleRegister} className="space-y-3 md:space-y-4 animate-in slide-in-from-right-4 duration-500">
               <div className="space-y-1.5">
                  <label className="text-[8px] md:text-[9px] font-black uppercase text-slate-400 ml-2 leading-none mb-1">Nama Lengkap</label>
                  <div className="relative">
                    <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input required type="text" value={formData.fullName} onChange={e => setFormData({...formData, fullName: e.target.value})} className="w-full pl-12 pr-4 md:pl-14 md:pr-6 py-3.5 md:py-4 bg-slate-50 rounded-2xl md:rounded-[2rem] outline-none font-bold text-xs shadow-inner" placeholder="Contoh: Zulkifli, S.Pd" />
                  </div>
               </div>
               <div className="space-y-1.5">
                  <label className="text-[8px] md:text-[9px] font-black uppercase text-slate-400 ml-2 leading-none mb-1">Nomor WA</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input required type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full pl-12 pr-4 md:pl-14 md:pr-6 py-3.5 md:py-4 bg-slate-50 rounded-2xl md:rounded-[2rem] outline-none font-bold text-xs shadow-inner" placeholder="0812345..." />
                  </div>
               </div>
               <div className="space-y-1.5">
                  <label className="text-[8px] md:text-[9px] font-black uppercase text-slate-400 ml-2 leading-none mb-1">Tugas Utama</label>
                  <div className="relative">
                    <select 
                      value={formData.role} 
                      onChange={e => setFormData({...formData, role: e.target.value as UserRole})} 
                      className="w-full px-5 md:px-6 py-3.5 md:py-4 bg-slate-50 rounded-2xl md:rounded-[2rem] font-black text-[9px] md:text-[10px] uppercase shadow-inner outline-none appearance-none border-2 border-transparent focus:border-emerald-600 cursor-pointer leading-tight"
                    >
                        {(Object.values(UserRole) as string[]).map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                    <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400"><ChevronDown size={14}/></div>
                  </div>
               </div>
               <button type="submit" disabled={loading} className="w-full bg-[#064e3b] text-white font-black py-4 md:py-5 rounded-[1.5rem] md:rounded-[2.5rem] shadow-xl uppercase text-[9px] md:text-[10px] tracking-[0.1em] md:tracking-[0.15em] hover:bg-emerald-800 transition-all mt-4 active:scale-95 leading-none">
                 {loading ? <RefreshCw className="animate-spin" size={18}/> : <ShieldCheck size={18}/>} Selesaikan Pendaftaran
               </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

const ChevronDown = ({size}: {size: number}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
);

export default Registration;