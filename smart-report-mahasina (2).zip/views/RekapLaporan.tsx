
import React, { useState, useMemo } from 'react';
import { 
  AppData, AttendanceStatus, Student, AttendanceRecord, 
  PrayerRecord, ReportItem, PrayerStatus, UserRole 
} from './utils/types.ts';
import { 
  Search, Download, Users, ClipboardCheck, Zap, 
  ShieldAlert, Trophy, Filter, User, FileSpreadsheet
} from 'lucide-react';
import { downloadCSV } from './csvExport.ts';
import { isTeacherMatch, normalizeClassName } from './utils/nameMatchers.ts';

interface RekapLaporanProps {
  data: AppData;
  profile: any;
}

const RekapLaporan: React.FC<RekapLaporanProps> = ({ data, profile }) => {
  const [activeMainTab, setActiveMainTab] = useState<'absen' | 'vp'>('absen');
  const [classFilter, setClassFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const students = data.students || [];

  const availableClasses = useMemo(() => {
    const cls = new Set<string>();
    students.forEach(s => {
      if (s.formalClass) cls.add(s.formalClass);
    });
    return Array.from(cls).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  }, [students]);

  const handleDownload = () => {
    if (!classFilter) return;
    downloadCSV([], `Rekap_${activeMainTab}_${classFilter}`);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="bg-white p-2 rounded-[2.5rem] shadow-sm flex gap-2 border border-slate-100 overflow-x-auto no-scrollbar">
        <button onClick={() => setActiveMainTab('absen')} className={`flex items-center gap-3 px-8 py-4 rounded-2xl whitespace-nowrap text-[10px] font-black uppercase tracking-widest transition-all ${activeMainTab === 'absen' ? 'bg-[#064e3b] text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`} >
          <ClipboardCheck size={18}/> Rekap Absensi
        </button>
        <button onClick={() => setActiveMainTab('vp')} className={`flex items-center gap-3 px-8 py-4 rounded-2xl whitespace-nowrap text-[10px] font-black uppercase tracking-widest transition-all ${activeMainTab === 'vp' ? 'bg-[#064e3b] text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`} >
          <ShieldAlert size={18}/> Rekap VP & Poin
        </button>
      </div>

      <div className="bg-white p-10 rounded-[4rem] border border-slate-50 shadow-sm space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="space-y-2 flex-1">
              <label className="text-[9px] font-black uppercase text-slate-400 ml-1">Unit Kelas Formal</label>
              <select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full p-4 bg-slate-50 rounded-2xl text-[10px] font-black uppercase outline-none shadow-inner border-2 border-transparent focus:border-emerald-600 appearance-none cursor-pointer">
                 <option value="">-- PILIH KELAS --</option>
                 {availableClasses.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
           </div>
           <div className="space-y-2 flex-1">
              <label className="text-[9px] font-black uppercase text-slate-400 ml-1">Cari Nama Santri</label>
              <div className="relative">
                 <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16}/>
                 <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Ketik nama..." className="w-full pl-12 pr-4 py-4 bg-slate-50 rounded-2xl outline-none text-[10px] font-bold shadow-inner border-2 border-transparent focus:border-emerald-600" />
              </div>
           </div>
        </div>

        {classFilter && (
           <div className="flex justify-end pt-4 border-t border-slate-50">
              <button onClick={handleDownload} className="px-8 py-4 bg-emerald-950 text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-3 shadow-xl active:scale-95 transition-all">
                 <FileSpreadsheet size={18}/> Unduh (.CSV)
              </button>
           </div>
        )}
      </div>

      <div className="bg-white p-10 rounded-[4.5rem] border border-slate-50 shadow-xl overflow-hidden min-h-[400px]">
         {!classFilter ? (
           <div className="flex flex-col items-center justify-center py-32 space-y-6 opacity-20">
              <Users size={64} className="text-slate-400" />
              <p className="text-[11px] font-black uppercase tracking-[0.3em] text-slate-800">Tentukan Unit Kelas Terlebih Dahulu</p>
           </div>
         ) : (
           <div className="py-24 text-center text-slate-300 font-black uppercase italic tracking-[0.3em] text-[10px] animate-pulse">
             Laporan Rekapitulasi Sedang Disusun...
           </div>
         )}
      </div>
    </div>
  );
};

export default RekapLaporan;
