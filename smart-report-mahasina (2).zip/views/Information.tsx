
import React, { useState, useMemo, useRef } from 'react';
import { 
  UserRole, AppData, Student, Teacher, Schedule, TemplateItem, OrganizationMember, ViolationCategory
} from './utils/types.ts';
import { 
  Search, Upload, Download, ArrowLeft, Edit, X, Save, 
  User, GraduationCap, Calendar, ShieldCheck, FileText, ChevronDown, 
  Trash2, Plus, Info, Database, Users, Trophy, BookOpen, Layers
} from 'lucide-react';
import { downloadCSV } from './csvExport.ts';
import * as XLSX from 'xlsx';

interface InformationProps {
  role: UserRole;
  userEmail: string;
  data: AppData;
  onUpdateData: (type: string, newData: any[]) => void;
}

const Information: React.FC<InformationProps> = ({ role, userEmail, data, onUpdateData }) => {
  const [selectedMenuId, setSelectedMenuId] = useState<string | null>(null);
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  
  // States Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('Semua');
  const [filterDay, setFilterDay] = useState('Semua');
  const [filterSession, setFilterSession] = useState('Semua');
  const [filterType, setFilterType] = useState('Pelanggaran'); // Untuk Peraturan
  const [filterGender, setFilterGender] = useState('Semua'); // Untuk ORSAM

  const isAdmin = userEmail.toLowerCase().trim() === 'idarohmahasina@gmail.com';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const menuCards = [
    { id: 'guru', label: 'Data Guru', desc: 'Profil Pengajar', color: 'emerald', icon: <GraduationCap size={24}/> },
    { id: 'santri', label: 'Data Santri', desc: 'Database Santri', color: 'indigo', icon: <User size={24}/> },
    { id: 'jadwal', label: 'Jadwal KBM', desc: 'Plotting Harian', color: 'amber', icon: <Calendar size={24}/> },
    { id: 'peraturan', label: 'Peraturan', desc: 'Katalog Poin', color: 'rose', icon: <ShieldCheck size={24}/> },
    { id: 'orsam', label: 'ORSAM', desc: 'Organisasi Santri', color: 'blue', icon: <Users size={24}/> },
    { id: 'orklas', label: 'ORKLAS', desc: 'Pengurus Kelas', color: 'cyan', icon: <Layers size={24}/> },
  ];

  // Logic Filtering Data
  const filteredList = useMemo(() => {
    const sTerm = searchTerm.toLowerCase();
    
    if (selectedMenuId === 'santri') {
      return data.students.filter(s => {
        const matchSearch = s.name.toLowerCase().includes(sTerm) || s.nis.includes(sTerm);
        const matchClass = filterClass === 'Semua' || s.formalClass === filterClass;
        return matchSearch && matchClass;
      }).sort((a, b) => a.name.localeCompare(b.name));
    }

    if (selectedMenuId === 'guru') {
      return data.teachers.filter(t => t.name.toLowerCase().includes(sTerm) || t.subject.toLowerCase().includes(sTerm))
        .sort((a, b) => a.name.localeCompare(b.name));
    }

    if (selectedMenuId === 'jadwal') {
      return data.schedules.filter(s => {
        const matchSearch = s.subject.toLowerCase().includes(sTerm) || s.teacherName.toLowerCase().includes(sTerm);
        const matchDay = filterDay === 'Semua' || s.day === filterDay;
        const matchSession = filterSession === 'Semua' || s.sessionType === filterSession;
        const matchClass = filterClass === 'Semua' || s.class === filterClass;
        return matchSearch && matchDay && matchSession && matchClass;
      }).sort((a, b) => a.day.localeCompare(b.day));
    }

    if (selectedMenuId === 'peraturan') {
      const source = filterType === 'Pelanggaran' ? data.violationTemplates : data.achievementTemplates;
      return (source || []).filter(t => t.label.toLowerCase().includes(sTerm));
    }

    if (selectedMenuId === 'orsam') {
      return (data.orsam || []).filter(o => {
        const matchSearch = o.name.toLowerCase().includes(sTerm);
        const matchGender = filterGender === 'Semua' || o.gender === filterGender;
        return matchSearch && matchGender;
      });
    }

    if (selectedMenuId === 'orklas') {
      return (data.orklas || []).filter(o => {
        const matchSearch = o.name.toLowerCase().includes(sTerm);
        const matchClass = filterClass === 'Semua' || o.class === filterClass;
        return matchSearch && matchClass;
      });
    }

    return [];
  }, [selectedMenuId, data, searchTerm, filterClass, filterDay, filterSession, filterType, filterGender]);

  // Master Data Update Handlers
  const handleUpdateMaster = (newData: any[]) => {
    let type = '';
    if (selectedMenuId === 'santri') type = 'Siswa';
    else if (selectedMenuId === 'guru') type = 'Guru';
    else if (selectedMenuId === 'jadwal') type = 'Jadwal';
    // Peraturan, ORSAM, ORKLAS bisa ditambahkan saveAppData jika sudah ada di service
    if (type) onUpdateData(type, newData);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json: any[] = XLSX.utils.sheet_to_json(ws);
        const normalized = json.map(item => ({
          ...item,
          id: item.id || `m-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        }));
        handleUpdateMaster(normalized);
        alert("Database Berhasil Sinkron!");
      } catch (err) { alert("Error pembacaan file Excel!"); }
    };
    reader.readAsBinaryString(file);
  };

  const handleDelete = (id: string) => {
    if (!confirm("Hapus data ini selamanya?")) return;
    let newList: any[] = [];
    if (selectedMenuId === 'santri') newList = data.students.filter(i => i.id !== id);
    else if (selectedMenuId === 'guru') newList = data.teachers.filter(i => i.id !== id);
    else if (selectedMenuId === 'jadwal') newList = data.schedules.filter(i => i.id !== id);
    handleUpdateMaster(newList);
  };

  const initNewItem = () => {
    setIsAddingNew(true);
    if (selectedMenuId === 'santri') setEditingItem({ name: '', nis: '', formalClass: '', level: 'MTs', gender: 'Putra' });
    else if (selectedMenuId === 'guru') setEditingItem({ name: '', subject: '', email: '', phone: '' });
    else if (selectedMenuId === 'jadwal') setEditingItem({ day: 'Senin', time: '', subject: '', teacherName: '', class: '', sessionType: 'Madrasah' });
    else if (selectedMenuId === 'peraturan') setEditingItem({ label: '', category: ViolationCategory.KEDISIPLINAN, points: 0 });
    else if (selectedMenuId === 'orsam' || selectedMenuId === 'orklas') setEditingItem({ name: '', nis: '', class: '', position: '', division: '', gender: 'Putra' });
  };

  const saveManual = (e: React.FormEvent) => {
    e.preventDefault();
    let currentList: any[] = [];
    if (selectedMenuId === 'santri') currentList = [...data.students];
    else if (selectedMenuId === 'guru') currentList = [...data.teachers];
    else if (selectedMenuId === 'jadwal') currentList = [...data.schedules];

    if (isAddingNew) currentList.push({ ...editingItem, id: `m-${Date.now()}` });
    else currentList = currentList.map(i => i.id === editingItem.id ? editingItem : i);

    handleUpdateMaster(currentList);
    setEditingItem(null);
    setIsAddingNew(false);
  };

  // --- UI RENDER: DASHBOARD KARTU ---
  if (!selectedMenuId) {
    return (
      <div className="space-y-12 animate-in fade-in duration-700 pb-32 max-w-6xl mx-auto px-4">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-[#064e3b] text-white rounded-[2.5rem] flex items-center justify-center mx-auto shadow-2xl"><Database size={36} /></div>
          <h2 className="text-3xl font-black uppercase tracking-tight text-slate-800">Pusat Informasi</h2>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.4em]">Database Master Pesantren Mahasina</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
          {menuCards.map((card) => (
            <button key={card.id} onClick={() => setSelectedMenuId(card.id)} className="bg-white p-6 md:p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all text-left group">
              <div className={`w-12 h-12 md:w-16 md:h-16 bg-${card.color}-50 text-${card.color}-600 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform shadow-sm`}>{card.icon}</div>
              <h3 className="text-[11px] md:text-[13px] font-black uppercase tracking-widest text-slate-800 mb-1">{card.label}</h3>
              <p className="text-[8px] md:text-[10px] font-bold text-slate-400 uppercase tracking-tight">{card.desc}</p>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // --- UI RENDER: LIST VIEW ---
  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-6 duration-500 pb-32 max-w-7xl mx-auto px-4">
      {/* List Header */}
      <div className="bg-white p-6 md:p-10 rounded-[3rem] border shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-6 w-full">
          <button onClick={() => setSelectedMenuId(null)} className="w-14 h-14 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center hover:bg-[#064e3b] hover:text-white transition-all border shadow-sm"><ArrowLeft size={20} /></button>
          <div>
             <h2 className="text-xl md:text-2xl font-black uppercase text-slate-800 leading-none mb-2">{menuCards.find(c => c.id === selectedMenuId)?.label}</h2>
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Manajemen Database {selectedMenuId}</p>
          </div>
        </div>
        
        {isAdmin && (
          <div className="flex flex-wrap gap-2 w-full md:w-auto justify-center md:justify-end">
            <button onClick={initNewItem} className="px-5 py-3 bg-[#064e3b] text-white rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg"><Plus size={14}/> Tambah Baru</button>
            <button onClick={() => fileInputRef.current?.click()} className="px-5 py-3 bg-emerald-50 text-emerald-700 rounded-xl text-[9px] font-black uppercase border border-emerald-100"><Upload size={14}/> Impor Excel</button>
            <button onClick={() => downloadCSV(filteredList, `Export_${selectedMenuId}`)} className="px-5 py-3 bg-slate-50 text-slate-600 rounded-xl text-[9px] font-black uppercase border"><Download size={14}/> Ekspor Data</button>
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".xlsx, .xls" />
          </div>
        )}
      </div>

      {/* List Filters */}
      <div className="bg-white p-6 rounded-[2.5rem] border shadow-sm grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative md:col-span-1">
           <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
           <input type="text" placeholder="Cari nama..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-slate-50 rounded-xl text-[10px] font-bold outline-none border shadow-inner" />
        </div>
        
        {/* Filter Dinamis per Kategori */}
        {(selectedMenuId === 'santri' || selectedMenuId === 'orklas') && (
           <select value={filterClass} onChange={e => setFilterClass(e.target.value)} className="p-3 bg-slate-50 rounded-xl text-[10px] font-black uppercase outline-none border shadow-inner">
              <option value="Semua">SEMUA KELAS</option>
              {Array.from(new Set(data.students.map(s => s.formalClass))).sort().map(c => <option key={c} value={c}>{c}</option>)}
           </select>
        )}

        {selectedMenuId === 'jadwal' && (
          <>
            <select value={filterDay} onChange={e => setFilterDay(e.target.value)} className="p-3 bg-slate-50 rounded-xl text-[10px] font-black uppercase outline-none border shadow-inner">
               <option value="Semua">SEMUA HARI</option>
               {['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Ahad'].map(d => <option key={d} value={d}>{d}</option>)}
            </select>
            <select value={filterSession} onChange={e => setFilterSession(e.target.value)} className="p-3 bg-slate-50 rounded-xl text-[10px] font-black uppercase outline-none border shadow-inner">
               <option value="Semua">SEMUA SESI</option>
               {['Madrasah', 'Al-Quran', 'Kitab Kuning', 'Umum'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={filterClass} onChange={e => setFilterClass(e.target.value)} className="p-3 bg-slate-50 rounded-xl text-[10px] font-black uppercase outline-none border shadow-inner">
               <option value="Semua">SEMUA KELAS</option>
               {Array.from(new Set(data.schedules.map(s => s.class))).sort().map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </>
        )}

        {selectedMenuId === 'peraturan' && (
           <div className="flex bg-slate-50 p-1 rounded-xl border md:col-span-1">
              <button onClick={() => setFilterType('Pelanggaran')} className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase transition-all ${filterType === 'Pelanggaran' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-400'}`}>Pelanggaran</button>
              <button onClick={() => setFilterType('Prestasi')} className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase transition-all ${filterType === 'Prestasi' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400'}`}>Prestasi</button>
           </div>
        )}

        {selectedMenuId === 'orsam' && (
           <select value={filterGender} onChange={e => setFilterGender(e.target.value)} className="p-3 bg-slate-50 rounded-xl text-[10px] font-black uppercase outline-none border shadow-inner">
              <option value="Semua">SEMUA GENDER</option>
              <option value="Putra">PUTRA</option>
              <option value="Putri">PUTRI</option>
           </select>
        )}
      </div>

      {/* List Table */}
      <div className="bg-white rounded-[2.5rem] border shadow-sm overflow-hidden min-h-[400px]">
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b">
              <tr className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                <th className="p-6">Nama / Identitas</th>
                <th className="p-6">Keterangan Detail</th>
                <th className="p-6">Label / Unit</th>
                {isAdmin && <th className="p-6 text-center">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-[11px] font-bold">
              {filteredList.map((item, idx) => (
                <tr key={item.id || idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="p-6">
                    <p className="font-black text-slate-800 uppercase leading-none mb-1.5">{item.name || item.label}</p>
                    <p className="text-[9px] font-bold text-slate-400 uppercase leading-none">{item.nis || item.teacherName || item.category || 'Record Data'}</p>
                  </td>
                  <td className="p-6">
                    <p className="leading-tight text-slate-600">{item.subject || item.day || item.position || (item.points ? `${item.points} Poin` : '-')}</p>
                    <p className="text-[8px] font-black text-slate-400 uppercase mt-1">{item.email || item.time || item.division || ''}</p>
                  </td>
                  <td className="p-6">
                    <span className="px-3 py-1 bg-slate-100 rounded-lg text-[8px] font-black text-slate-500 uppercase">{item.formalClass || item.class || item.level || 'Umum'}</span>
                    {item.sessionType && <span className="ml-2 px-3 py-1 bg-emerald-50 rounded-lg text-[8px] font-black text-emerald-600 uppercase">{item.sessionType}</span>}
                  </td>
                  {isAdmin && (
                    <td className="p-6">
                      <div className="flex justify-center gap-2">
                         <button onClick={() => setEditingItem(item)} className="p-2 bg-blue-50 text-blue-600 rounded-lg"><Edit size={14}/></button>
                         <button onClick={() => handleDelete(item.id)} className="p-2 bg-red-50 text-red-600 rounded-lg"><Trash2 size={14}/></button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
              {filteredList.length === 0 && (
                <tr><td colSpan={isAdmin ? 4 : 3} className="py-24 text-center text-[10px] font-black uppercase text-slate-300 italic tracking-widest">Data tidak ditemukan</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Entry / Edit Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
           <div className="bg-white rounded-[2.5rem] w-full max-w-lg p-10 space-y-8 animate-in zoom-in-95 shadow-2xl relative max-h-[90vh] overflow-y-auto no-scrollbar">
              <button onClick={() => { setEditingItem(null); setIsAddingNew(false); }} className="absolute top-8 right-8 p-3 bg-slate-50 text-slate-400 rounded-2xl"><X size={20}/></button>
              <h3 className="text-xl font-black uppercase text-slate-800">{isAddingNew ? 'Data Manual' : 'Edit Record'}</h3>
              <form onSubmit={saveManual} className="space-y-6">
                 {/* Field dinamis menyesuaikan menu */}
                 <EditField label="Nama / Label" value={editingItem.name || editingItem.label} onChange={v => setEditingItem({...editingItem, [editingItem.label !== undefined ? 'label' : 'name']: v})} />
                 
                 {(selectedMenuId === 'santri' || selectedMenuId === 'guru') && <EditField label="Identitas (NIS/Mapel)" value={editingItem.nis || editingItem.subject} onChange={v => setEditingItem({...editingItem, [editingItem.nis !== undefined ? 'nis' : 'subject']: v})} />}
                 
                 <EditField label="Unit / Kelas" value={editingItem.formalClass || editingItem.class} onChange={v => setEditingItem({...editingItem, [editingItem.formalClass !== undefined ? 'formalClass' : 'class']: v})} />
                 
                 <button type="submit" className="w-full py-5 bg-[#064e3b] text-white rounded-2xl font-black uppercase text-[11px] shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-3">
                    <Save size={18}/> Simpan Perubahan
                 </button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

const EditField: React.FC<{ label: string, value: string, onChange: (v: string) => void }> = ({ label, value, onChange }) => (
  <div className="space-y-1 text-left">
     <label className="text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">{label}</label>
     <input type="text" value={value || ''} onChange={e => onChange(e.target.value)} className="w-full p-4 bg-slate-50 rounded-2xl text-[11px] font-bold outline-none border-2 border-transparent focus:border-emerald-600 transition-all shadow-inner" />
  </div>
);

export default Information;
