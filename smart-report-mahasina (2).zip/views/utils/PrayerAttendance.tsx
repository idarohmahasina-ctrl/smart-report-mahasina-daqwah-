
import React, { useState, useMemo } from 'react';
import { PrayerTime, PrayerStatus, Student, PrayerRecord, UserRole } from './types.ts';
import { 
  Save, ArrowLeft, Calendar as CalendarIcon, CheckCircle2, AlertCircle, 
  Clock, Filter, ChevronRight, Edit, Trash2, X, PieChart as PieChartIcon, Search, Users, TrendingUp
} from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface PrayerAttendanceProps {
  students: Student[];
  allPrayerRecords: PrayerRecord[];
  currentUser: string;
  userRole?: UserRole;
  onSave: (recs: PrayerRecord[]) => void;
  onUpdate?: (rec: PrayerRecord) => void;
  onDelete?: (id: string) => void;
}

const COLORS = ['#064e3b', '#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

const PrayerAttendance: React.FC<PrayerAttendanceProps> = ({ 
  students, allPrayerRecords, currentUser, userRole, onSave, onUpdate, onDelete
}) => {
  const [mainTab, setMainTab] = useState<'stats' | 'input' | 'history'>('stats');
  
  // States Filter Statistik
  const [statDate, setStatDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [statSession, setStatSession] = useState<string>('Semua');
  const [statLevel, setStatLevel] = useState<string>('Semua');
  const [statGender, setStatGender] = useState<string>('Semua');
  const [statClass, setStatClass] = useState<string>('Semua');
  const [rankStatusFilter, setRankStatusFilter] = useState<PrayerStatus>(PrayerStatus.ALPHA);

  // States Riwayat
  const [historyDate, setHistoryDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedHistoryKey, setSelectedHistoryKey] = useState<string | null>(null);
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);

  // States Input Baru
  const [selectedInputDate, setSelectedInputDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [inputSession, setInputSession] = useState<PrayerTime>(PrayerTime.SUBUH);
  const [inputClass, setInputClass] = useState<string | null>(null);
  const [inputMap, setInputMap] = useState<Record<string, { status: PrayerStatus, note: string }>>({});

  const dateToIdStr = (d: string) => {
    if (!d) return "";
    const [y, m, d_] = d.split('-');
    return `${d_}/${m}/${y}`;
  };

  // --- LOGIC STATISTIK ---
  const filteredStatsRecords = useMemo(() => {
    const targetDate = dateToIdStr(statDate);
    return allPrayerRecords.filter(r => {
      const s = students.find(std => std.id === r.studentId);
      if (!s) return false;
      const matchDate = r.date === targetDate;
      const matchSession = statSession === 'Semua' || r.prayerTime === statSession;
      const matchLevel = statLevel === 'Semua' || s.level === statLevel;
      const matchGender = statGender === 'Semua' || s.gender === statGender;
      const matchClass = statClass === 'Semua' || s.formalClass === statClass;
      return matchDate && matchSession && matchLevel && matchGender && matchClass;
    });
  }, [allPrayerRecords, students, statDate, statSession, statLevel, statGender, statClass]);

  const summary = useMemo(() => {
    const counts: Record<string, number> = {
      [PrayerStatus.JAMAAH]: 0,
      [PrayerStatus.SAKIT]: 0,
      [PrayerStatus.IZIN]: 0,
      [PrayerStatus.TERLAMBAT]: 0,
      [PrayerStatus.ALPHA]: 0,
      [PrayerStatus.UDZUR]: 0,
    };
    filteredStatsRecords.forEach(r => { if(counts[r.status] !== undefined) counts[r.status]++; });
    return counts;
  }, [filteredStatsRecords]);

  const rankings = useMemo(() => {
    const sMap: Record<string, { name: string, count: number, class: string }> = {};
    const cMap: Record<string, { name: string, count: number }> = {};

    filteredStatsRecords.filter(r => r.status === rankStatusFilter).forEach(r => {
      const s = students.find(std => std.id === r.studentId);
      if (s) {
        if (!sMap[s.id]) sMap[s.id] = { name: s.name, count: 0, class: s.formalClass };
        sMap[s.id].count++;
        if (!cMap[s.formalClass]) cMap[s.formalClass] = { name: s.formalClass, count: 0 };
        cMap[s.formalClass].count++;
      }
    });

    return {
      students: Object.values(sMap).sort((a, b) => b.count - a.count).slice(0, 5),
      classes: Object.values(cMap).sort((a, b) => b.count - a.count).slice(0, 5)
    };
  }, [filteredStatsRecords, rankStatusFilter, students]);

  // --- UI COMPONENTS ---
  const FilterItem = ({ label, value, onChange, options }: any) => (
    <div className="space-y-1">
      <p className="text-[8px] font-black text-slate-400 uppercase ml-1 tracking-widest">{label}</p>
      <select value={value} onChange={e => onChange(e.target.value)} className="w-full p-2.5 bg-slate-50 border border-slate-100 rounded-xl text-[9px] font-black uppercase outline-none shadow-sm focus:border-emerald-600 transition-all">
        {options.map((opt: any) => <option key={opt} value={opt}>{opt.toUpperCase()}</option>)}
      </select>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-32">
      {/* Menu Tabs */}
      <div className="bg-white p-1.5 rounded-2xl shadow-lg flex gap-1 border border-slate-100 max-w-2xl mx-auto">
        {[
          { id: 'stats', label: 'STATISTIK' },
          { id: 'input', label: 'INPUT' },
          { id: 'history', label: 'HISTORI' },
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => { setMainTab(tab.id as any); setSelectedHistoryKey(null); }}
            className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mainTab === tab.id ? 'bg-[#064e3b] text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* VIEW: STATISTIK */}
      {mainTab === 'stats' && (
        <div className="space-y-6 animate-in slide-in-from-bottom-4">
          {/* Header & Filter */}
          <div className="bg-white p-6 md:p-10 rounded-[2.5rem] border shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b pb-4">
               <Filter size={18} className="text-emerald-600" />
               <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-800">Filter Analisis Pondok</h3>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
               <div className="space-y-1">
                  <p className="text-[8px] font-black text-slate-400 uppercase ml-1 tracking-widest">Tanggal</p>
                  <input type="date" value={statDate} onChange={e => setStatDate(e.target.value)} className="w-full p-2.5 bg-slate-50 border border-slate-100 rounded-xl text-[9px] font-black uppercase outline-none" />
               </div>
               <FilterItem label="Kegiatan" value={statSession} onChange={setStatSession} options={['Semua', ...Object.values(PrayerTime)]} />
               <FilterItem label="Tingkatan" value={statLevel} onChange={setStatLevel} options={['Semua', 'MTs', 'MA']} />
               <FilterItem label="Gender" value={statGender} onChange={setStatGender} options={['Semua', 'Putra', 'Putri']} />
               <FilterItem label="Kelas" value={statClass} onChange={setStatClass} options={['Semua', ...Array.from(new Set(students.map(s => s.formalClass))).sort()]} />
            </div>
          </div>

          {/* Cards & Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
             <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {Object.entries(summary).map(([label, val], i) => (
                  <div key={label} className="bg-white p-5 rounded-3xl border-l-4 shadow-sm flex flex-col justify-center" style={{ borderLeftColor: COLORS[i % COLORS.length] }}>
                    <p className="text-[8px] font-black text-slate-400 uppercase leading-none mb-2 truncate">{label}</p>
                    <p className="text-2xl font-black text-slate-800">{val}</p>
                  </div>
                ))}
             </div>
             <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border shadow-sm flex flex-col items-center justify-center min-h-[300px]">
                <h3 className="text-[10px] font-black uppercase text-slate-800 tracking-widest mb-4">Komposisi Kehadiran</h3>
                <div className="w-full h-64">
                   <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                         <Pie 
                            data={Object.entries(summary).map(([name, value]) => ({ name, value: value as number })).filter(d => (d.value as number) > 0)} 
                            innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value"
                         >
                            {COLORS.map((color, index) => <Cell key={`cell-${index}`} fill={color} />)}
                         </Pie>
                         <Tooltip />
                         <Legend />
                      </PieChart>
                   </ResponsiveContainer>
                </div>
             </div>
          </div>

          {/* Ranking */}
          <div className="bg-white p-8 md:p-12 rounded-[3rem] border shadow-sm space-y-8">
             <div className="flex flex-col md:flex-row justify-between items-center gap-6">
                <div>
                   <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Peringkat Log Pondok</h3>
                   <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Filter Ranking Berdasarkan Status:</p>
                </div>
                <div className="flex bg-slate-50 p-1.5 rounded-2xl gap-1 border">
                   {Object.values(PrayerStatus).map(s => (
                     <button key={s} onClick={() => setRankStatusFilter(s)} className={`px-4 py-2 rounded-xl text-[8px] font-black uppercase transition-all ${rankStatusFilter === s ? 'bg-[#064e3b] text-white shadow-lg' : 'text-slate-400 hover:text-emerald-950'}`}>
                        {s === PrayerStatus.JAMAAH ? 'H' : s.charAt(0)}
                     </button>
                   ))}
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-800 uppercase tracking-[0.2em] border-b pb-3">Top 5 Santri ({rankStatusFilter})</p>
                   {rankings.students.length > 0 ? rankings.students.map((r, i) => (
                     <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                        <div className="flex items-center gap-4">
                           <span className="text-[11px] font-black text-slate-300 w-4">{i+1}.</span>
                           <div className="min-w-0">
                              <p className="text-[11px] font-black text-slate-800 uppercase truncate leading-none mb-1">{r.name}</p>
                              <p className="text-[8px] font-bold text-slate-400 uppercase leading-none">{r.class}</p>
                           </div>
                        </div>
                        <span className="text-lg font-black text-emerald-700">{r.count}</span>
                     </div>
                   )) : <p className="text-[10px] italic text-slate-300 py-10 text-center">Data tidak ditemukan</p>}
                </div>
                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-800 uppercase tracking-[0.2em] border-b pb-3">Top 5 Kelas ({rankStatusFilter})</p>
                   {rankings.classes.length > 0 ? rankings.classes.map((r, i) => (
                     <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                        <div className="flex items-center gap-4">
                           <span className="text-[11px] font-black text-slate-300 w-4">{i+1}.</span>
                           <p className="text-[11px] font-black text-slate-800 uppercase truncate leading-none">{r.name}</p>
                        </div>
                        <span className="text-lg font-black text-emerald-700">{r.count}</span>
                     </div>
                   )) : <p className="text-[10px] italic text-slate-300 py-10 text-center">Data tidak ditemukan</p>}
                </div>
             </div>
          </div>
        </div>
      )}

      {/* VIEW: INPUT BARU */}
      {mainTab === 'input' && (
        <div className="animate-in slide-in-from-bottom-4 space-y-6">
          {!inputClass ? (
            <div className="bg-white p-8 md:p-14 rounded-[3rem] border shadow-xl space-y-10">
               <div className="text-center space-y-2">
                  <h2 className="text-xl font-black uppercase text-slate-800">Presensi Baru Pondok</h2>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Input kehadiran kegiatan asrama</p>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                  <div className="space-y-1.5 text-left">
                     <p className="text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Pilih Tanggal</p>
                     <div className="relative">
                        <CalendarIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-600" size={16} />
                        <input type="date" value={selectedInputDate} onChange={e => setSelectedInputDate(e.target.value)} className="w-full pl-12 p-4 bg-slate-50 border rounded-2xl text-[10px] font-black uppercase shadow-inner" />
                     </div>
                  </div>
                  <div className="space-y-1.5 text-left">
                     <p className="text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Pilih Sesi</p>
                     <select value={inputSession} onChange={e => setInputSession(e.target.value as PrayerTime)} className="w-full p-4 bg-slate-50 border rounded-2xl text-[10px] font-black uppercase shadow-inner">
                        {Object.values(PrayerTime).map(pt => <option key={pt} value={pt}>{pt}</option>)}
                     </select>
                  </div>
               </div>
               <div className="grid grid-cols-3 md:grid-cols-5 gap-3 pt-6 border-t">
                  {Array.from(new Set(students.map(s => s.formalClass))).sort().map(cls => (
                    <button key={cls} onClick={() => {
                      setInputClass(cls);
                      const roster = students.filter(s => s.formalClass === cls);
                      const initialMap: any = {};
                      roster.forEach(s => { initialMap[s.id] = { status: PrayerStatus.JAMAAH, note: '' } });
                      setInputMap(initialMap);
                    }} className="p-6 bg-slate-50 border border-slate-100 rounded-[2rem] hover:bg-emerald-50 hover:border-emerald-200 transition-all text-center group">
                       <p className="text-[11px] font-black uppercase text-slate-800 group-hover:scale-110 transition-transform">{cls}</p>
                       <p className="text-[7px] font-black text-slate-300 uppercase mt-2 tracking-widest">PILIH UNIT</p>
                    </button>
                  ))}
               </div>
            </div>
          ) : (
            <div className="space-y-4 animate-in slide-in-from-right-8 pb-32">
               <div className="flex items-center justify-between px-3">
                  <button onClick={() => setInputClass(null)} className="flex items-center gap-2 text-slate-400 hover:text-emerald-700 font-black uppercase text-[10px] tracking-widest"><ArrowLeft size={16}/> KEMBALI</button>
                  <div className="text-right">
                     <h3 className="text-[11px] font-black text-slate-800 uppercase leading-none">{inputSession}</h3>
                     <p className="text-[8px] font-bold text-emerald-600 uppercase mt-1 tracking-widest">{inputClass} • {dateToIdStr(selectedInputDate)}</p>
                  </div>
               </div>
               <div className="space-y-1">
                  {students.filter(s => s.formalClass === inputClass).map((s, idx) => (
                    <div key={s.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between gap-4">
                       <div className="flex items-center gap-3 min-w-0 flex-1">
                          <span className="text-[10px] font-black text-slate-200 w-5 shrink-0">{idx+1}.</span>
                          <div className="min-w-0">
                             <h4 className="text-[11px] font-black text-slate-800 uppercase truncate leading-none mb-1">{s.name}</h4>
                             <p className="text-[8px] font-bold text-slate-400 uppercase leading-none">{s.nis}</p>
                          </div>
                       </div>
                       <div className="flex gap-1 overflow-x-auto no-scrollbar">
                          {Object.values(PrayerStatus).map(st => {
                            const label = st === PrayerStatus.JAMAAH ? 'H' : st.charAt(0);
                            const isActive = inputMap[s.id]?.status === st;
                            return (
                              <button key={st} onClick={() => setInputMap(p => ({ ...p, [s.id]: { ...p[s.id], status: st } }))} className={`w-8 h-8 rounded-lg text-[10px] font-black transition-all border flex items-center justify-center ${isActive ? 'bg-[#064e3b] text-white border-[#064e3b] shadow-md scale-110' : 'bg-slate-50 text-slate-400'}`}>
                                 {label}
                              </button>
                            );
                          })}
                       </div>
                    </div>
                  ))}
               </div>
               <div className="fixed bottom-6 left-0 right-0 px-4 z-50">
                  <button onClick={() => {
                    const timeStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                    const newRecs: PrayerRecord[] = Object.entries(inputMap).map(([sId, data]: [string, any]) => ({
                      id: `pr-${Date.now()}-${sId}`,
                      date: dateToIdStr(selectedInputDate),
                      recordedTime: timeStr,
                      studentId: sId,
                      status: data.status,
                      recordedBy: currentUser,
                      class: inputClass!,
                      prayerTime: inputSession,
                      note: data.note
                    }));
                    onSave(newRecs);
                    alert("Berhasil disimpan!");
                    setInputClass(null);
                  }} className="w-full max-w-md mx-auto py-5 bg-[#064e3b] text-white rounded-[2.5rem] font-black uppercase text-[11px] tracking-[0.2em] shadow-2xl flex items-center justify-center gap-3">
                     <Save size={18}/> SIMPAN ABSEN PONDOK
                  </button>
               </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW: HISTORI */}
      {mainTab === 'history' && (
        <div className="space-y-6 animate-in slide-in-from-bottom-4">
           {selectedHistoryKey ? (
              /* DETAIL HISTORI + EDIT */
              <div className="space-y-4 animate-in slide-in-from-right-8 pb-32">
                 <div className="flex items-center justify-between px-3">
                    <button onClick={() => setSelectedHistoryKey(null)} className="flex items-center gap-2 text-slate-400 font-black uppercase text-[10px] tracking-widest"><ArrowLeft size={16}/> KEMBALI</button>
                    <div className="text-right">
                       {/* Fix: Explicitly cast selectedHistoryKey to string and handle parts safely to avoid unknown type error */}
                       {(() => {
                         const keyParts = (selectedHistoryKey as string).split('-');
                         return (
                           <>
                             <h3 className="text-[11px] font-black text-slate-800 uppercase">{keyParts[0]}</h3>
                             <p className="text-[8px] font-bold text-emerald-600 uppercase tracking-widest">{keyParts[1] || ''} • {dateToIdStr(historyDate)}</p>
                           </>
                         );
                       })()}
                    </div>
                 </div>
                 <div className="space-y-1">
                    {allPrayerRecords.filter(r => r.date === dateToIdStr(historyDate) && `${r.prayerTime}-${r.class}` === selectedHistoryKey).map((record, idx) => {
                      const s = students.find(std => std.id === record.studentId);
                      const isEditing = editingRecordId === record.id;
                      return (
                        <div key={record.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between gap-4">
                           <div className="flex items-center gap-3 min-w-0 flex-1">
                              <span className="text-[10px] font-black text-slate-200 w-5">{idx+1}.</span>
                              <div className="min-w-0">
                                 <h4 className="text-[10px] font-black text-slate-800 uppercase truncate leading-none mb-1">{s?.name || 'Unknown'}</h4>
                                 <p className="text-[8px] font-bold text-slate-400 uppercase leading-none">Status: {record.status}</p>
                              </div>
                           </div>
                           <div className="flex items-center gap-2">
                              {!isEditing ? (
                                <>
                                  <span className={`px-2 py-1 rounded-md text-[8px] font-black ${record.status === PrayerStatus.JAMAAH ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>{record.status.charAt(0)}</span>
                                  <button onClick={() => setEditingRecordId(record.id)} className="p-2 text-slate-300 hover:text-blue-500"><Edit size={14}/></button>
                                  {onDelete && <button onClick={() => { if(confirm("Hapus?")) onDelete(record.id); }} className="p-2 text-slate-300 hover:text-red-500"><Trash2 size={14}/></button>}
                                </>
                              ) : (
                                <div className="flex gap-1 animate-in zoom-in-95">
                                   {Object.values(PrayerStatus).map(st => (
                                     <button key={st} onClick={() => { onUpdate?.({ ...record, status: st }); setEditingRecordId(null); }} className={`w-7 h-7 rounded-lg text-[8px] font-black border ${record.status === st ? 'bg-blue-600 text-white' : 'bg-slate-50'}`}>{st.charAt(0)}</button>
                                   ))}
                                   <button onClick={() => setEditingRecordId(null)} className="p-2 text-slate-400"><X size={14}/></button>
                                </div>
                              )}
                           </div>
                        </div>
                      );
                    })}
                 </div>
              </div>
           ) : (
              /* LIST SESI HISTORI */
              <div className="space-y-6">
                 <div className="bg-white p-6 rounded-[2.5rem] border shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                       <Clock size={20} className="text-emerald-600" />
                       <h3 className="text-sm font-black uppercase text-slate-800">Log Harian Pondok</h3>
                    </div>
                    <input type="date" value={historyDate} onChange={e => setHistoryDate(e.target.value)} className="w-full md:w-64 p-3 bg-slate-50 border rounded-xl text-[10px] font-black uppercase outline-none shadow-inner" />
                 </div>
                 <div className="space-y-2">
                    {Array.from(new Set(allPrayerRecords.filter(r => r.date === dateToIdStr(historyDate)).map(r => `${r.prayerTime}-${r.class}`))).map((key: any) => {
                       const count = allPrayerRecords.filter(r => r.date === dateToIdStr(historyDate) && `${r.prayerTime}-${r.class}` === key).length;
                       return (
                         <button key={key} onClick={() => setSelectedHistoryKey(key)} className="w-full bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center justify-between group hover:border-emerald-200 transition-all text-left">
                            <div>
                               {/* Fix: Explicitly cast key to string before split to avoid unknown type error */}
                               <p className="text-[8px] font-black text-emerald-600 uppercase tracking-widest mb-1.5">{(key as string).split('-')[0]}</p>
                               <h3 className="text-[11px] font-black text-slate-800 uppercase leading-none mb-1">UNIT: {(key as string).split('-')[1]}</h3>
                               <p className="text-[8px] font-bold text-slate-400 uppercase">{count} Santri Terdata</p>
                            </div>
                            <ChevronRight size={18} className="text-slate-300 group-hover:text-emerald-600" />
                         </button>
                       );
                    })}
                    {allPrayerRecords.filter(r => r.date === dateToIdStr(historyDate)).length === 0 && (
                       <div className="py-24 text-center opacity-30 italic text-[10px] font-black uppercase tracking-widest">Belum ada riwayat pada tanggal ini</div>
                    )}
                 </div>
              </div>
           )}
        </div>
      )}
    </div>
  );
};

export default PrayerAttendance;
