
import React, { useState, useMemo, useRef } from 'react';
import { ReportItem, UserRole, ViolationCategory, Student, TemplateItem } from './types.ts';
import { 
  Search, X, Send, Camera, Image as ImageIcon, BookOpen, AlertCircle, 
  CheckCircle2, Clock, Calendar, User, ChevronRight, Edit, History, ArrowLeft,
  UserCheck, ShieldCheck, Zap, Trash2, Save, Plus
} from 'lucide-react';

interface ReportsProps {
  type: 'Violation' | 'Achievement';
  role: UserRole;
  currentUser: string;
  students: Student[];
  allReports: ReportItem[];
  templates: TemplateItem[];
  onSave: (rep: ReportItem) => void;
  onUpdate?: (rep: ReportItem) => void;
}

const Reports: React.FC<ReportsProps> = ({ 
  type, role, currentUser, students, allReports, templates, onSave, onUpdate 
}) => {
  const [view, setView] = useState<'form' | 'history'>('form');
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);

  // Form State
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [category, setCategory] = useState<ViolationCategory>(ViolationCategory.KEDISIPLINAN);
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateItem | null>(null);
  const [isCustom, setIsCustom] = useState(false);
  const [customLabel, setCustomLabel] = useState('');
  const [customPoints, setCustomPoints] = useState(0);
  const [actionNote, setActionNote] = useState('');
  const [description, setDescription] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  
  const isIdaroh = role === UserRole.IDAROH;
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Pencarian santri dengan detail sinkron
  const filteredStudents = useMemo(() => {
    if (searchTerm.length < 2) return [];
    const term = searchTerm.toLowerCase();
    return students.filter(s => 
      s.name.toLowerCase().includes(term) || 
      s.nis.includes(term)
    ).slice(0, 5);
  }, [searchTerm, students]);

  // Katalog poin sesuai kategori
  const categoryTemplates = useMemo(() => {
    return templates.filter(t => t.category === category);
  }, [templates, category]);

  const handleSave = () => {
    if (!selectedStudent) { alert("Pilih santri!"); return; }
    if (!isCustom && !selectedTemplate) { alert("Pilih detail dari katalog!"); return; }
    if (isCustom && (!customLabel || !customPoints)) { alert("Lengkapi data custom!"); return; }

    // Jika kolom tindakan diisi, status otomatis 'Ditindak'
    const finalStatus: 'Ditindak' | 'Belum Ditindak' = actionNote.trim().length > 0 ? 'Ditindak' : 'Belum Ditindak';
    
    const newReport: ReportItem = {
      id: `rep-${Date.now()}`,
      studentId: selectedStudent.id,
      type: type,
      category: category,
      points: isCustom ? customPoints : (selectedTemplate?.points || 0),
      description: isCustom ? customLabel : (selectedTemplate?.label || ''),
      date: new Date().toLocaleDateString('id-ID'),
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      reporter: currentUser,
      status: finalStatus,
      actionNote: actionNote.trim() || undefined,
      photoUrl: photo || undefined
    };

    onSave(newReport);
    alert(`Laporan Berhasil! Status: ${finalStatus}`);
    resetForm();
    setView('history');
  };

  const resetForm = () => {
    setSelectedStudent(null);
    setSearchTerm('');
    setCategory(ViolationCategory.KEDISIPLINAN);
    setSelectedTemplate(null);
    setIsCustom(false);
    setCustomLabel('');
    setCustomPoints(0);
    setActionNote('');
    setDescription('');
    setPhoto(null);
  };

  const themeBg = type === 'Violation' ? 'bg-[#7f1d1d]' : 'bg-[#064e3b]';
  const themeText = type === 'Violation' ? 'text-red-800' : 'text-emerald-800';

  // Detail View
  const activeReportDetail = useMemo(() => {
    return allReports.find(r => r.id === selectedReportId);
  }, [allReports, selectedReportId]);

  if (selectedReportId && activeReportDetail) {
    const student = students.find(s => s.id === activeReportDetail.studentId);
    return (
      <div className="space-y-6 animate-in slide-in-from-right-10 duration-500 pb-32">
        <button onClick={() => setSelectedReportId(null)} className="flex items-center gap-2 text-slate-400 font-black uppercase text-[10px] tracking-widest px-2">
           <ArrowLeft size={16}/> KEMBALI
        </button>

        <div className="bg-white rounded-[2.5rem] border shadow-sm overflow-hidden">
           <div className={`${activeReportDetail.type === 'Violation' ? 'bg-red-50' : 'bg-emerald-50'} p-8 text-center border-b`}>
              <h3 className={`text-xl font-black uppercase tracking-tight ${themeText}`}>Detail Laporan</h3>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">{activeReportDetail.date} • {activeReportDetail.time} WIB</p>
           </div>
           
           <div className="p-8 space-y-6 text-left">
              <div className="flex items-center gap-4 border-b pb-6">
                 <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center font-black text-slate-400 text-xl border">{student?.name.charAt(0)}</div>
                 <div className="min-w-0">
                    <h4 className="text-sm font-black text-slate-800 uppercase leading-none mb-2">{student?.name}</h4>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">{student?.nis} • {student?.formalClass}</p>
                    <p className="text-[8px] font-black text-emerald-600 uppercase mt-1 tracking-widest">{student?.level} • {student?.gender}</p>
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Bidang</p>
                    <p className="text-[11px] font-black text-slate-800 uppercase">{activeReportDetail.category}</p>
                 </div>
                 <div className="p-4 bg-slate-50 rounded-2xl">
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Poin</p>
                    <p className="text-[11px] font-black text-slate-800 uppercase">{activeReportDetail.points} PT</p>
                 </div>
              </div>

              <div className="space-y-2">
                 <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Keterangan Laporan</p>
                 <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 italic text-[11px] text-slate-600 font-bold leading-relaxed whitespace-pre-wrap">{activeReportDetail.description}</div>
              </div>

              {activeReportDetail.actionNote && (
                 <div className="space-y-2">
                    <p className="text-[8px] font-black text-emerald-600 uppercase tracking-widest ml-1">{activeReportDetail.type === 'Violation' ? 'Tindakan / Sanksi' : 'Apresiasi'}</p>
                    <div className="p-5 bg-emerald-50 rounded-2xl border border-emerald-100 text-[11px] text-emerald-800 font-black leading-relaxed">{activeReportDetail.actionNote}</div>
                 </div>
              )}

              {activeReportDetail.photoUrl && (
                 <div className="space-y-2">
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Bukti Foto</p>
                    <img src={activeReportDetail.photoUrl} alt="Bukti" className="w-full h-auto rounded-3xl border shadow-sm" />
                 </div>
              )}

              <div className="flex items-center justify-between border-t pt-6">
                 <div>
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-2">Pelapor:</p>
                    <div className="flex items-center gap-2 text-[10px] font-black text-slate-800 uppercase">
                       <User size={14} className="text-emerald-600" /> {activeReportDetail.reporter}
                    </div>
                 </div>
                 <div className="text-right">
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest leading-none mb-2">Status:</p>
                    <span className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest ${activeReportDetail.status === 'Ditindak' ? 'bg-emerald-600 text-white shadow-md' : 'bg-red-600 text-white'}`}>{activeReportDetail.status}</span>
                 </div>
              </div>

              {isIdaroh && (
                <div className="pt-6 border-t space-y-4">
                   <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-center gap-3">
                      <ShieldCheck size={18} className="text-amber-600 shrink-0" />
                      <p className="text-[9px] font-bold text-amber-700 uppercase leading-tight">Akses Khusus Idaroh: Anda dapat mengubah status laporan ini secara manual.</p>
                   </div>
                   <button 
                    onClick={() => {
                      const newStatus = activeReportDetail.status === 'Ditindak' ? 'Belum Ditindak' : 'Ditindak';
                      onUpdate?.({ ...activeReportDetail, status: newStatus as any });
                    }} 
                    className="w-full py-5 bg-[#064e3b] text-white rounded-[2rem] font-black uppercase text-[11px] tracking-widest flex items-center justify-center gap-3 active:scale-95 transition-all shadow-xl"
                   >
                     <Edit size={16}/> UBAH STATUS PENINDAKAN
                   </button>
                </div>
              )}
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-32 max-w-4xl mx-auto px-1">
      <div className={`${themeBg} p-8 md:p-12 rounded-[2.5rem] shadow-2xl text-white text-center space-y-6 relative overflow-hidden`}>
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
        <h2 className="text-xl md:text-2xl font-black uppercase tracking-tight leading-none relative z-10">
          {type === 'Violation' ? 'Pelanggaran Santri' : 'Prestasi Santri'}
        </h2>
        <div className="flex bg-black/10 p-1.5 rounded-2xl max-w-sm mx-auto relative z-10">
          <button onClick={() => setView('form')} className={`flex-1 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${view === 'form' ? 'bg-white text-slate-800 shadow-xl' : 'text-white/40'}`}>INPUT DATA</button>
          <button onClick={() => setView('history')} className={`flex-1 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${view === 'history' ? 'bg-white text-slate-800 shadow-xl' : 'text-white/40'}`}>RIWAYAT</button>
        </div>
      </div>

      {view === 'form' && (
        <div className="space-y-6 animate-in slide-in-from-bottom-4">
          <div className="bg-white p-6 md:p-12 rounded-[2.5rem] border shadow-sm space-y-10">
            {/* 1. Pencarian Santri (Otomatis Sinkron) */}
            <div className="space-y-4">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-3 text-left">1. Cari Nama Santri</p>
              {!selectedStudent ? (
                <div className="relative">
                  <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300" size={24} />
                  <input type="text" placeholder="Ketik nama santri..." className="w-full pl-16 pr-8 py-6 bg-slate-50 rounded-[2rem] outline-none font-bold text-sm border-2 border-transparent focus:border-emerald-600 transition-all shadow-inner" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                  {filteredStudents.length > 0 && (
                    <div className="absolute top-full left-0 w-full mt-2 bg-white rounded-3xl border shadow-2xl z-50 overflow-hidden">
                      {filteredStudents.map(s => (
                        <button key={s.id} onClick={() => setSelectedStudent(s)} className="w-full p-6 flex items-center gap-6 hover:bg-slate-50 border-b last:border-0 text-left transition-colors">
                          <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center font-black text-xs text-slate-400 shrink-0">{s.name.charAt(0)}</div>
                          <div className="min-w-0 flex-1">
                            <p className="text-[12px] font-black text-slate-800 uppercase mb-1 truncate">{s.name}</p>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{s.nis} • {s.formalClass} • {s.level} • {s.gender}</p>
                          </div>
                          <ChevronRight size={16} className="ml-auto text-slate-200" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className={`p-6 ${type === 'Violation' ? 'bg-red-50/50' : 'bg-emerald-50/50'} rounded-[2.5rem] border-2 border-dashed flex flex-col md:flex-row items-center justify-between gap-6 animate-in zoom-in-95`}>
                  <div className="flex items-center gap-6 text-left">
                    <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center font-black text-slate-800 text-xl border shadow-sm shrink-0">{selectedStudent.name.charAt(0)}</div>
                    <div className="min-w-0">
                      <h4 className="text-[13px] font-black text-slate-800 uppercase leading-none mb-2 truncate">{selectedStudent.name}</h4>
                      <div className="flex flex-wrap gap-2">
                         <span className="text-[8px] font-black uppercase bg-white px-3 py-1.5 rounded-lg border text-slate-500 shadow-sm">NIS: {selectedStudent.nis}</span>
                         <span className="text-[8px] font-black uppercase bg-[#064e3b] text-white px-3 py-1.5 rounded-lg shadow-sm">{selectedStudent.formalClass}</span>
                         <span className="text-[8px] font-black uppercase bg-white px-3 py-1.5 rounded-lg border text-emerald-600">{selectedStudent.level}</span>
                         <span className="text-[8px] font-black uppercase bg-white px-3 py-1.5 rounded-lg border text-slate-400">{selectedStudent.gender}</span>
                      </div>
                    </div>
                  </div>
                  <button onClick={() => setSelectedStudent(null)} className="px-6 py-3 bg-white text-red-600 font-black text-[9px] uppercase border border-red-100 rounded-xl shadow-sm hover:bg-red-50 transition-all flex items-center gap-2">
                    <X size={14} /> GANTI SANTRI
                  </button>
                </div>
              )}
            </div>

            {/* 2. Detail Laporan */}
            {selectedStudent && (
              <div className="space-y-6 animate-in slide-in-from-top-4 duration-500">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="space-y-1.5 text-left">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-3">2. Pilih Kategori</p>
                      <select value={category} onChange={e => { setCategory(e.target.value as any); setSelectedTemplate(null); }} className="w-full p-5 bg-slate-50 border-2 border-transparent focus:border-emerald-600 rounded-[1.5rem] font-black text-[11px] uppercase tracking-widest outline-none shadow-inner transition-all">
                         {Object.values(ViolationCategory).map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                   </div>
                   <div className="space-y-1.5 text-left">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-3">3. Detail (Katalog Poin)</p>
                      <select 
                        value={isCustom ? 'custom' : (selectedTemplate?.label || '')} 
                        onChange={e => {
                          const val = e.target.value;
                          if (val === 'custom') { setIsCustom(true); setSelectedTemplate(null); }
                          else { setIsCustom(false); setSelectedTemplate(categoryTemplates.find(t => t.label === val) || null); }
                        }} 
                        className="w-full p-5 bg-slate-50 border-2 border-transparent focus:border-emerald-600 rounded-[1.5rem] font-black text-[11px] uppercase tracking-widest outline-none shadow-inner transition-all"
                      >
                         <option value="">-- Lihat Katalog --</option>
                         {categoryTemplates.map(t => <option key={t.label} value={t.label}>{t.label.toUpperCase()} ({t.points} PT)</option>)}
                         <option value="custom" className="text-emerald-700 font-black">INPUT MANUAL (CUSTOM)</option>
                      </select>
                   </div>
                </div>

                {isCustom && (
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 animate-in slide-in-from-top-2 text-left">
                    <div className="md:col-span-3 space-y-1.5">
                       <p className="text-[9px] font-black text-amber-600 uppercase tracking-widest ml-3">Deskripsi Manual</p>
                       <input type="text" value={customLabel} onChange={e => setCustomLabel(e.target.value)} className="w-full p-5 bg-amber-50/50 border-2 border-amber-100 rounded-[1.5rem] text-[11px] font-black uppercase outline-none shadow-inner" placeholder="Tulis rincian..." />
                    </div>
                    <div className="space-y-1.5">
                       <p className="text-[9px] font-black text-amber-600 uppercase tracking-widest ml-3">Poin</p>
                       <input type="number" value={customPoints} onChange={e => setCustomPoints(Number(e.target.value))} className="w-full p-5 bg-amber-50/50 border-2 border-amber-100 rounded-[1.5rem] text-[11px] font-black outline-none shadow-inner" />
                    </div>
                  </div>
                )}

                {!isCustom && selectedTemplate && (
                   <div className="p-5 bg-emerald-50 rounded-[1.5rem] border border-emerald-100 flex items-center justify-between text-left">
                      <div>
                        <p className="text-[8px] font-black text-emerald-600 uppercase tracking-[0.2em] mb-1">Terpilih</p>
                        <h5 className="text-[11px] font-black text-emerald-900 uppercase">{selectedTemplate.label}</h5>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-black text-emerald-700">{selectedTemplate.points}</p>
                        <p className="text-[7px] font-black text-emerald-400 uppercase">POIN</p>
                      </div>
                   </div>
                )}

                <div className="space-y-1.5 text-left">
                   <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-3">4. Keterangan / Kronologi</p>
                   <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Tuliskan detail kejadian..." className="w-full p-6 bg-slate-50 rounded-[1.5rem] text-[11px] font-bold outline-none border-2 border-transparent focus:border-emerald-600 shadow-inner h-32 resize-none transition-all" />
                </div>

                <div className="space-y-1.5 text-left">
                   <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-3">5. Tindakan / Sanksi (Opsional)</p>
                   <div className="relative">
                      <input type="text" value={actionNote} onChange={e => setActionNote(e.target.value)} placeholder="Misal: Hafalan Juz Amma / Teguran Lisan..." className="w-full p-6 bg-slate-50 border-2 border-transparent focus:border-emerald-600 rounded-[1.5rem] text-[11px] font-black uppercase outline-none shadow-inner italic transition-all" />
                      {actionNote.length > 0 && <div className="absolute right-4 top-1/2 -translate-y-1/2 bg-emerald-600 text-white p-2 rounded-full shadow-lg"><UserCheck size={14} /></div>}
                   </div>
                   {actionNote.length > 0 && <p className="text-[8px] font-black text-emerald-600 uppercase ml-3 tracking-widest">Ada tindakan: Status otomatis "DITINDAK"</p>}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <button onClick={() => fileInputRef.current?.click()} className="py-5 bg-slate-50 border-2 border-dashed border-slate-200 text-slate-500 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest shadow-sm flex items-center justify-center gap-3 active:scale-95 transition-all hover:bg-slate-100">
                      {photo ? <CheckCircle2 size={18} className="text-emerald-600"/> : <Camera size={18}/>}
                      {photo ? 'FOTO TERLAMPIR' : 'AMBIL FOTO / GALERI'}
                   </button>
                   <div className="p-5 bg-slate-50 rounded-[1.5rem] border flex items-center gap-3">
                      <User size={16} className="text-emerald-600" />
                      <div className="text-left">
                        <p className="text-[8px] font-black text-slate-400 uppercase leading-none mb-1">Nama Pelapor</p>
                        <p className="text-[10px] font-black text-slate-800 uppercase leading-none">{currentUser}</p>
                      </div>
                   </div>
                   <input type="file" ref={fileInputRef} onChange={(e) => {
                     const f = e.target.files?.[0];
                     if(f) { const r = new FileReader(); r.onloadend = () => setPhoto(r.result as string); r.readAsDataURL(f); }
                   }} className="hidden" accept="image/*" />
                </div>
              </div>
            )}
          </div>
          
          <button onClick={handleSave} disabled={!selectedStudent} className={`w-full py-6 rounded-[2.5rem] font-black uppercase text-[12px] tracking-[0.3em] shadow-2xl flex items-center justify-center gap-4 active:scale-95 transition-all ${themeBg} text-white disabled:opacity-40 leading-none`}>
             <Zap size={20} /> SIMPAN LAPORAN RESMI
          </button>
        </div>
      )}

      {view === 'history' && (
        <div className="space-y-4 animate-in slide-in-from-bottom-4 duration-500">
           <div className="space-y-2">
              {allReports.filter(r => r.type === type).sort((a,b) => b.id.localeCompare(a.id)).slice(0, 20).map(report => {
                const s = students.find(std => std.id === report.studentId);
                return (
                  <button key={report.id} onClick={() => setSelectedReportId(report.id)} className="w-full bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm flex items-center justify-between group hover:shadow-md transition-all text-left">
                     <div className="min-w-0 pr-4">
                        <p className="text-[8px] font-black text-slate-300 uppercase leading-none mb-1.5">{report.date} • {report.time} WIB</p>
                        <h4 className="text-[11px] font-black text-slate-800 uppercase truncate leading-none mb-2">{s?.name || 'Unknown'}</h4>
                        <div className="flex items-center gap-3">
                           <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{report.category}</span>
                           <span className={`px-2 py-0.5 rounded text-[7px] font-black uppercase ${report.status === 'Ditindak' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>{report.status}</span>
                        </div>
                     </div>
                     <ChevronRight size={18} className="text-slate-200 group-hover:text-emerald-600 transition-colors shrink-0" />
                  </button>
                );
              })}
           </div>
        </div>
      )}
    </div>
  );
};

export default Reports;
