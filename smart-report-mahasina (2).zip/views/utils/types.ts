
export enum UserRole {
  GURU = 'Guru',
  MUSYRIF = 'Musyrif/ah & Walas',
  OFFICER_PUTRA = 'Petugas Santri Putra',
  OFFICER_PUTRI = 'Petugas santri Putri',
  IDAROH = 'Petugas Idaroh',
  PENGASUH = 'Pengasuh'
}

export enum AttendanceStatus {
  H = 'Hadir',
  S = 'Sakit',
  I = 'Izin',
  T = 'Terlambat',
  A = 'Alpha',
  LIBUR = 'Libur'
}

export enum ViolationCategory {
  KEDISIPLINAN = 'Kedisiplinan',
  AKADEMIK = 'Akademik',
  IBADAH = 'Ibadah',
  AKHLAQ = 'Akhlaq',
  KEBERSIHAN = 'Kebersihan'
}

export enum PrayerTime {
  SUBUH = 'Subuh',
  DHUHA = 'Dhuha',
  DZUHUR = 'Dzuhur',
  ASHAR = 'Ashar',
  MAGHRIB = 'Maghrib',
  ISYA = 'Isya',
  KHATAMAN = 'Khataman Al-Quran',
  LALARAN = 'Lalaran Ahad Malam',
  SENAM = 'Senam Pagi'
}

export enum PrayerStatus {
  JAMAAH = "Berjama'ah",
  UDZUR = 'Udzur',
  SAKIT = 'Sakit',
  IZIN = 'Izin',
  TERLAMBAT = 'Terlambat',
  ALPHA = 'Alpha'
}

export interface Student {
  id: string;
  nis: string;
  name: string;
  formalClass: string;
  sessionClasses?: Record<string, string>;
  level: 'MTs' | 'MA';
  gender: 'Putra' | 'Putri';
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  status: AttendanceStatus;
  date: string;
  time: string;
  note: string;
  recordedBy: string;
  class: string;
  sessionType: string;
}

export interface ReportItem {
  id: string;
  studentId: string;
  type: 'Violation' | 'Achievement';
  category: ViolationCategory;
  points: number;
  description: string;
  date: string;
  time: string;
  reporter: string;
  status: 'Belum Ditindak' | 'Ditindak';
  actionNote?: string;
  photoUrl?: string;
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  phone: string;
  email: string;
  teachingClasses: string[];
  isSubstitute?: boolean;
}

export interface Schedule {
  id: string;
  class: string;
  level: 'MTs' | 'MA';
  gender: 'Putra' | 'Putri';
  day: string;
  time: string;
  subject: string;
  teacherName: string;
  substituteTeacherName?: string;
  assistantTeacherName?: string;
  homeroomTeacherName?: string;
  sessionType: string;
}

export interface TeacherAttendance {
  id: string;
  date: string;
  teacherEmail: string;
  teacherName: string;
  subject: string;
  class: string;
  sessionType?: string;
  startTime: string;
  summary: string;
  status: AttendanceStatus;
  photoUrl?: string;
}

export interface PrayerRecord {
  id: string;
  date: string;
  recordedTime: string;
  studentId: string;
  status: PrayerStatus;
  recordedBy: string;
  class: string;
  prayerTime: PrayerTime;
  note?: string;
}

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  role: UserRole;
  isBlocked?: boolean;
  lastActive?: any;
}

export interface AcademicConfig {
  semester: string;
  schoolYear: string;
  excludedSessions?: Record<string, boolean>;
  sessionClassExclusions?: Record<string, Record<string, boolean>>;
}

export interface TemplateItem {
  label: string;
  category: ViolationCategory;
  points: number;
}

export interface OrganizationMember {
  id: string;
  name: string;
  nis: string;
  class: string;
  position: string;
  division: string;
  gender: 'Putra' | 'Putri';
  orgType: 'ORSAM' | 'ORKLAS' | 'HAMASAH';
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  author: string;
  category?: string;
}

export interface AppData {
  attendance: AttendanceRecord[];
  reports: ReportItem[];
  students: Student[];
  teachers: Teacher[];
  schedules: Schedule[];
  prayerAttendance: PrayerRecord[];
  teacherAttendance: TeacherAttendance[];
  academicConfig: AcademicConfig;
  violationTemplates: TemplateItem[];
  achievementTemplates: TemplateItem[];
  orsam: OrganizationMember[];
  orklas: OrganizationMember[];
  extraDataLists: any[];
  announcements: Announcement[];
}

export type SessionType = 'Madrasah' | 'Al-Quran' | 'Kitab Kuning' | 'Umum';
