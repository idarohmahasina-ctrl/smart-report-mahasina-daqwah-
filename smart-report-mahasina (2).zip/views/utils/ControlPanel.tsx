import React, { useState, useMemo } from 'react';
import { 
  AttendanceRecord, PrayerRecord, TeacherAttendance, ReportItem, Student, 
  UserRole, AppData, AttendanceStatus, ViolationCategory, PrayerStatus, PrayerTime
} from './types.ts';
import { 
  ShieldCheck, Lock, Trash2, Search, Database, 
  X, Check, AlertTriangle, Download, FileText, UserCheck, Zap,
  AlertCircle, RefreshCcw, ShieldAlert, Sparkles, User, Key, GraduationCap, CheckCircle, Edit, Save, Calendar, Clock
} from 'lucide-react';
import { downloadCSV } from '../csvExport.ts';

interface ControlPanelProps {
  data: AppData;
  actions: {
    deleteAttendance: (id: string) => void;
    deletePrayer: (id: string) => void;
    deleteReport: (id: string) => void;
    deleteTeacherAttendance: (id: string) => void;
    updateAttendance: (updated: AttendanceRecord) => void;
    updatePrayer: (updated: PrayerRecord) => void;
    updateReport: (updated: ReportItem) => void;
    updateTeacherAttendance: (updated: TeacherAttendance) => void;
  };
}

const ControlPanel: React.FC<ControlPanelProps> = ({ data, actions }) => {
  const [activeModul, setActiveModul] = useState<'absen-kbm' | 'absen-pondok' | 'absen-guru' | 'pelanggaran' | 'prestasi'>('absen-kbm');
  const [searchTerm, setSearchTerm] = useState('');
  const [pin, setPin] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);

  const [filterDate, setFilterDate] = useState<string>('');
  const [filterClass, setFilterClass] = useState<string>('Semua');

  const [editingItem, setEditingItem] = useState<any | null>(null);

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === '7777') setIsAuthorized(true);
    else { alert("PIN Salah!"); setPin(''); }
  };

  const filteredData = useMemo(() => {
    let list: any[] = [];
    if (activeModul === 'absen-kbm') list = data.attendance || [];
    else if (activeModul === 'absen-pondok') list = data.prayerAttendance || [];
    else if (activeModul === 'absen-guru') list = data.teacherAttendance || [];
    else if (activeModul === 'pelanggaran') list = (data.reports || []).filter(r => r.type === 'Violation');
    else if (activeModul === 'prestasi') list = (data.reports || []).filter(r => r.type === 'Achievement');

    return list.filter(item => {
      const student = data.students?.find(s => s.id === item.studentId);
      const searchStr = `${student?.name || ''} ${item.teacherName || ''} ${item.recordedBy || item.reporter || ''}`.toLowerCase();
      const matchSearch = searchStr.includes(searchTerm.toLowerCase());
      const matchClass = filterClass === 'Semua' || item.class === filterClass || student?.formalClass === filterClass;
      
      let matchDate = true;
      if (filterDate) {
        const [d, m, y] = item.date.split('/').map(Number);
        const itemIsoDate = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
        matchDate = itemIsoDate === filterDate;
      }

      return matchSearch && matchClass && matchDate;
    }).sort((a,b) => b.date.localeCompare(a.date));
  }, [activeModul, data, searchTerm, filterDate, filterClass]);

  const handleUpdate = () => {
    if (!editingItem) return;
    if (activeModul === 'absen-kbm') actions.updateAttendance(editingItem);
    else if (activeModul === 'absen-pondok') actions.updatePrayer(editingItem);
    else if (activeModul === 'absen-guru') actions.updateTeacherAttendance(editingItem);
    else actions.updateReport(editingItem);
    setEditingItem(null);
    alert("Audit Ter-update");
  };

  if (!isAuthorized) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center animate-in fade-in zoom-in-95 px-4">
        <div className="bg-white p-8 md:p-12 rounded-[2rem] md:rounded-[4rem] shadow-2xl border w-full max-w-sm text-center space-y-6 md:space-y-8">
           <div className="w-16 h-16 md:w-20 md:h-20 bg-emerald-50 text-emerald-600 rounded-2xl md:rounded-3xl flex items-center justify-center mx-auto shrink-0"><Lock size={32} /></div>
           <h2 className="text-lg md:text-xl font-black uppercase text-slate-800 leading-none">Audit Authority</h2>
           <form onSubmit={handleVerifyPin} className="space-y-5 md:space-y-6">
              <input type="password" maxLength={4} value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))} placeholder="****" className="w-full text-center py-4 md:py-6 text-3xl md:text-4xl font-black tracking-[0.5em] bg-slate-50 rounded-2xl md:rounded-[2rem] border-2 border-transparent focus:border-emerald-600 outline-none shadow-inner" autoFocus />
              <button type="submit" className="w-full py-4 md:py-5 bg-[#064e3b] text-white rounded-2xl md:rounded-[2rem] font-black uppercase text-[10px] md:text-[11px] shadow-xl active:scale-95 transition-all">Buka Audit Panel</button>
           </form>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-10 pb-32 animate-in fade-in max-w-6xl mx-auto px-1">
      <div className="bg-emerald-950 p-6 md:p-12 rounded-[1.5rem] md:rounded-[3.5rem] shadow-2xl relative overflow-hidden text-white border-b-4 border-emerald-500">
        <div className="relative z-10 flex flex-col items-center md:flex-row md:justify-between gap-6 md:gap-8">
           <div className="flex items-center gap-4 md:gap-8 text-center md:text-left flex-col md:flex-row">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-white/10 rounded-xl md:rounded-2xl flex items-center justify-center text-emerald-400 backdrop-blur-md shrink-0"><Database size={24} className="md:w-8 md:h-8" /></div>
              <div className="min-w-0">
                 <h2 className="text-base md:text-2xl font-black uppercase tracking-tight leading-none mb-1.5 md:mb-3">Audit Panel</h2>
                 <p className="text-[7px] md:text-[10px] font-black text-emerald-400 uppercase tracking-[0.2em] md:tracking-[0.4em] leading-none">Validasi Data • Log Petugas</p>
              </div>
           </div>
           <div className="flex flex-wrap bg-white/5 p-1 rounded-xl border border-white/10 backdrop-blur-sm gap-1 w-full md:w-auto overflow-x-auto no-scrollbar">
              {['absen-kbm', 'absen-pondok', 'absen-guru', 'pelanggaran', 'prestasi'].map(tab => (
                <button key={tab} onClick={() => setActiveModul(tab as any)} className={`flex-1 min-w-[70px] px-2 md:px-4 py-2 md:py-2.5 rounded-lg md:rounded-xl text-[7px] md:text-[8px] font-black uppercase transition-all whitespace-nowrap ${activeModul === tab ? 'bg-white text-emerald-950 shadow-xl' : 'text-white/60 hover:text-white'}`}>{tab.replace('-', ' ')}</button>
              ))}
           </div>
        </div>
      </div>

      <div className="bg-white p-5 md:p-12 rounded-[1.5rem] md:rounded-[4rem] border shadow-xl space-y-6 md:space-y-10">
         <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-6">
            <div className="relative">
               <span className="absolute left-4 md:left-6 top-1/2 -translate-y-1/2 text-slate-400"><Search size={14}/></span>
               <input type="text" placeholder="Cari data..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 md:pl-14 md:pr-6 py-2.5 md:py-3 bg-slate-50 border-2 border-transparent focus:border-emerald-600 rounded-xl md:rounded-2xl outline-none font-bold text-[8px] md:text-[9px] uppercase shadow-inner" />
            </div>
            <div className="space-y-1">
               <input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)} className="w-full p-2.5 md:p-3 bg-slate-50 rounded-xl md:rounded-2xl text-[8px] md:text-[9px] font-black outline-none border border-transparent focus:border-emerald-600 shadow-inner" />
            </div>
            <button onClick={() => downloadCSV(filteredData, `Log_Audit`)} className="px-4 md:px-8 py-2.5 md:py-3 bg-emerald-900 text-white rounded-xl md:rounded-2xl font-black uppercase text-[8px] md:text-[9px] shadow-lg flex items-center justify-center gap-2 md:gap-3 transition-all active:scale-95"><Download size={14}/> Ekspor Audit</button>
         </div>

         <div className="overflow-x-auto no-scrollbar min-h-[300px]">
            <table className="w-full text-left min-w-[800px]">
               <thead className="bg-slate-50">
                  <tr className="text-[8px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest border-b-2 border-slate-100">
                     <th className="p-4 md:p-6 pr-4">Identitas</th>
                     <th className="p-4 md:p-6 pr-4">Detail</th>
                     <th className="p-4 md:p-6 pr-4 text-center">Status</th>
                     <th className="p-4 md:p-6 pr-4">Petugas</th>
                     <th className="p-4 md:p-6 text-center">Aksi</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-50 text-[9px] md:text-[11px]">
                  {filteredData.map((item) => (
                    <tr key={item.id} className="group hover:bg-slate-50 transition-all">
                      <td className="p-4 md:p-6 pr-4">
                         <p className="font-black text-slate-800 uppercase leading-tight mb-1 truncate max-w-[120px] md:max-w-none">{item.teacherName || data.students?.find(s => s.id === item.studentId)?.name || 'N/A'}</p>
                         <p className="text-[7px] md:text-[8px] font-bold text-slate-400 uppercase tracking-tighter leading-none truncate">KELAS: {item.class}</p>
                      </td>
                      <td className="p-4 md:p-6 pr-4">
                         <p className="font-bold text-slate-700 leading-tight mb-1 truncate max-w-[100px] md:max-w-none">{item.sessionType || item.prayerTime || item.category || item.subject || item.type}</p>
                         <p className="text-[7px] md:text-[8px] font-black text-slate-400 uppercase leading-none">{item.date}</p>
                      </td>
                      <td className="p-4 md:p-6 pr-4 text-center">
                         <span className={`px-2 md:px-2.5 py-0.5 md:py-1 rounded-md md:rounded-lg text-[7px] md:text-[9px] font-black uppercase whitespace-nowrap ${item.status === 'Hadir' || item.status === "Berjama'ah" || item.status === 'Ditindak' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>{item.status || 'HADIR'}</span>
                      </td>
                      <td className="p-4 md:p-6 pr-4 whitespace-nowrap">
                         <div className="flex flex-col gap-1">
                            <div className="flex items-center gap-1.5 text-slate-800 leading-none">
                               <User size={10} className="text-emerald-500 shrink-0" />
                               <p className="font-black uppercase truncate max-w-[80px] md:max-w-none">{item.recordedBy || item.reporter || item.teacherName || 'Sistem'}</p>
                            </div>
                            <div className="flex items-center gap-1.5 text-slate-400 leading-none">
                               <Clock size={10} className="shrink-0" />
                               <p className="font-bold uppercase">{item.startTime || item.time || item.recordedTime || '-'} WIB</p>
                            </div>
                         </div>
                      </td>
                      <td className="p-4 md:p-6 whitespace-nowrap">
                         <div className="flex justify-center gap-1.5 md:gap-2">
                            <button onClick={() => setEditingItem({ ...item })} className="p-2 md:p-3 bg-blue-50 text-blue-600 rounded-lg md:rounded-xl border border-blue-100 hover:bg-blue-600 hover:text-white transition-all shadow-sm"><Edit size={14}/></button>
                            <button onClick={() => { if(confirm("Hapus?")) { if(activeModul === 'absen-kbm') actions.deleteAttendance(item.id); else if(activeModul === 'absen-pondok') actions.deletePrayer(item.id); else if(activeModul === 'absen-guru') actions.deleteTeacherAttendance(item.id); else actions.deleteReport(item.id); } }} className="p-2 md:p-3 bg-red-50 text-red-600 rounded-lg md:rounded-xl border border-red-100 hover:bg-red-600 hover:text-white transition-all shadow-sm"><Trash2 size={14}/></button>
                         </div>
                      </td>
                    </tr>
                  ))}
                  {filteredData.length === 0 && (
                     <tr><td colSpan={5} className="py-20 text-center text-[9px] font-black text-slate-300 uppercase italic">Log audit kosong</td></tr>
                  )}
               </tbody>
            </table>
         </div>
      </div>

      {editingItem && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
           <div className="bg-white rounded-[1.5rem] md:rounded-[3rem] w-full max-w-md p-6 md:p-10 space-y-6 md:space-y-8 animate-in zoom-in-95 shadow-2xl">
              <div className="flex justify-between items-center"><h3 className="text-base md:text-xl font-black uppercase tracking-tight leading-none">Audit Data</h3><button onClick={() => setEditingItem(null)} className="p-2 bg-slate-100 rounded-lg text-slate-400 hover:text-red-600"><X size={20}/></button></div>
              <div className="space-y-4 md:space-y-6">
                 <div className="space-y-1.5">
                    <label className="text-[8px] md:text-[10px] font-black text-slate-400 uppercase ml-1">Koreksi Status</label>
                    <select value={editingItem.status} onChange={e => setEditingItem({...editingItem, status: e.target.value})} className="w-full p-3 md:p-4 bg-slate-50 border rounded-xl md:rounded-2xl outline-none font-bold text-xs md:text-sm uppercase shadow-inner">
                      {activeModul === 'absen-kbm' && (Object.values(AttendanceStatus) as string[]).map(s => <option key={s} value={s}>{s}</option>)}
                      {activeModul === 'absen-pondok' && (Object.values(PrayerStatus) as string[]).map(s => <option key={s} value={s}>{s}</option>)}
                      {(activeModul === 'pelanggaran' || activeModul === 'prestasi') && ['Belum Ditindak', 'Ditindak'].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                 </div>
                 <div className="space-y-1.5">
                    <label className="text-[8px] md:text-[10px] font-black text-slate-400 uppercase ml-1">Catatan Audit</label>
                    <textarea value={editingItem.note || editingItem.description || editingItem.summary || ''} onChange={e => { const val = e.target.value; if (activeModul === 'absen-kbm' || activeModul === 'absen-pondok') setEditingItem({...editingItem, note: val}); else if (activeModul === 'absen-guru') setEditingItem({...editingItem, summary: val}); else setEditingItem({...editingItem, description: val}); }} className="w-full p-3 md:p-5 bg-slate-50 border rounded-xl md:rounded-2xl outline-none font-bold text-xs md:text-sm min-h-[80px] md:min-h-[100px] shadow-inner resize-none" />
                 </div>
              </div>
              <button onClick={handleUpdate} className="w-full py-4 md:py-5 bg-emerald-950 text-white rounded-xl md:rounded-[2rem] font-black uppercase text-[10px] md:text-[11px] shadow-2xl flex items-center justify-center gap-2 md:gap-3 transition-all active:scale-95"><Save size={18}/> Perbarui Audit</button>
           </div>
        </div>
      )}
    </div>
  );
};

export default ControlPanel;