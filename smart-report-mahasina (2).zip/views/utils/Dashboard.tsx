
import React, { useState, useMemo } from 'react';
import { 
  Filter, Download, TrendingUp, User, Users, Calendar, Clock, Award, ShieldAlert, ChevronDown, BookOpen, GraduationCap, CheckCircle2, AlertCircle, Coffee
} from 'lucide-react';
import { 
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend
} from 'recharts';
import { 
  AppData, UserProfile, AttendanceStatus, ViolationCategory, Student, AttendanceRecord, TeacherAttendance, ReportItem, Schedule
} from './types.ts';
import * as XLSX from 'xlsx';
import { isTeacherMatch } from './nameMatchers.ts';

const COLORS = ['#064e3b', '#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

interface DashboardProps {
  data: AppData;
  profile: UserProfile;
}

const Dashboard: React.FC<DashboardProps> = ({ data, profile }) => {
  const [activeTab, setActiveTab] = useState<'kbm' | 'guru' | 'monitoring' | 'pelanggaran' | 'prestasi'>('kbm');
  const [timeFilter, setTimeFilter] = useState('month'); 
  const [customDate, setCustomDate] = useState('');
  const [levelFilter, setLevelFilter] = useState('Semua');
  const [genderFilter, setGenderFilter] = useState('Semua');
  const [sessionFilter, setSessionFilter] = useState('Semua');
  const [classFilter, setClassFilter] = useState('Semua');
  const [rankFilter, setRankFilter] = useState<string>('Alpha');

  // New state for monitoring date filter
  const [monitoringDate, setMonitoringDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const isAdmin = profile.email.toLowerCase().trim() === 'idarohmahasina@gmail.com';

  const matchesTime = (dateStr: string) => {
    if (!dateStr) return false;
    const [d, m, y] = dateStr.split('/').map(Number);
    const date = new Date(y, m - 1, d);
    const now = new Date();
    
    if (timeFilter === 'today') return date.toDateString() === now.toDateString();
    if (timeFilter === 'week') {
      const start = new Date();
      start.setDate(now.getDate() - 7);
      return date >= start;
    }
    if (timeFilter === 'month') return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
    if (timeFilter === 'semester') {
      const month = date.getMonth();
      const nowMonth = now.getMonth();
      const isGanjil = month >= 6 && month <= 11;
      const isNowGanjil = nowMonth >= 6 && nowMonth <= 11;
      return isGanjil === isNowGanjil && date.getFullYear() === now.getFullYear();
    }
    if (timeFilter === 'custom' && customDate) {
      const custom = new Date(customDate);
      return date.toDateString() === custom.toDateString();
    }
    return true;
  };

  const filteredKbmData = useMemo(() => {
    return data.attendance.filter(a => {
      const s = data.students.find(std => std.id === a.studentId);
      if (!s) return false;
      const tMatch = matchesTime(a.date);
      const lMatch = levelFilter === 'Semua' || s.level === levelFilter;
      const gMatch = genderFilter === 'Semua' || s.gender === genderFilter;
      const sMatch = sessionFilter === 'Semua' || a.sessionType === sessionFilter;
      const cMatch = classFilter === 'Semua' || a.class === classFilter;
      return tMatch && lMatch && gMatch && sMatch && cMatch;
    });
  }, [data, timeFilter, customDate, levelFilter, genderFilter, sessionFilter, classFilter]);

  const filteredTeacherData = useMemo(() => {
    return data.teacherAttendance.filter(ta => {
      const tMatch = matchesTime(ta.date);
      const cMatch = classFilter === 'Semua' || ta.class === classFilter;
      return tMatch && cMatch;
    });
  }, [data.teacherAttendance, timeFilter, customDate, classFilter]);

  const kbmStats = useMemo(() => {
    const counts: Record<string, number> = { Hadir: 0, Sakit: 0, Izin: 0, Terlambat: 0, Alpha: 0 };
    filteredKbmData.forEach(a => { if (counts[a.status] !== undefined) counts[a.status]++; });
    return counts;
  }, [filteredKbmData]);

  const teacherStats = useMemo(() => {
    const counts: Record<string, number> = { Hadir: 0, Sakit: 0, Izin: 0, Libur: 0 };
    filteredTeacherData.forEach(ta => { 
        if (ta.status === AttendanceStatus.H) counts.Hadir++;
        if (ta.status === AttendanceStatus.S) counts.Sakit++;
        if (ta.status === AttendanceStatus.I) counts.Izin++;
        if (ta.status === AttendanceStatus.LIBUR) counts.Libur++;
    });
    return counts;
  }, [filteredTeacherData]);

  const monitoringData = useMemo(() => {
    if (!isAdmin) return { teachers: [], classes: [] };
    
    // Parse selected monitoring date
    const mDate = new Date(monitoringDate);
    const mDayNameRaw = new Intl.DateTimeFormat('id-ID', { weekday: 'long' }).format(mDate);
    const mDayName = mDayNameRaw === 'Minggu' ? 'Ahad' : mDayNameRaw;
    const mDateStr = mDate.toLocaleDateString('id-ID');

    const selectedDaySchedules = data.schedules.filter(s => s.day === mDayName);
    
    const classStatus = selectedDaySchedules.map(s => {
      const hasSubmitted = data.attendance.some(a => 
        a.date === mDateStr && a.class === s.class && a.sessionType === s.sessionType
      );
      return { ...s, status: hasSubmitted ? 'Sudah Absen' : 'Belum Absen' };
    });

    const teacherStatus = selectedDaySchedules.map(s => {
      const hasSubmitted = data.teacherAttendance.some(ta => 
        ta.date === mDateStr && ta.class === s.class && ta.subject === s.subject && isTeacherMatch(ta.teacherName, s.teacherName)
      );
      return { ...s, status: hasSubmitted ? 'Sudah Absen' : 'Belum Absen' };
    });

    return { classes: classStatus, teachers: teacherStatus, dayName: mDayName, dateStr: mDateStr };
  }, [data, monitoringDate, isAdmin]);

  const filteredReportData = useMemo(() => {
    const type = activeTab === 'pelanggaran' ? 'Violation' : 'Achievement';
    return data.reports.filter(r => {
      const s = data.students.find(std => std.id === r.studentId);
      if (!s) return false;
      if (r.type !== type) return false;
      const tMatch = matchesTime(r.date);
      const lMatch = levelFilter === 'Semua' || s.level === levelFilter;
      const gMatch = genderFilter === 'Semua' || s.gender === genderFilter;
      const cMatch = classFilter === 'Semua' || s.formalClass === classFilter;
      return tMatch && lMatch && gMatch && cMatch;
    });
  }, [data, activeTab, timeFilter, customDate, levelFilter, genderFilter, classFilter]);

  const reportStats = useMemo(() => {
    const total = filteredReportData.length;
    const ditindak = filteredReportData.filter(r => r.status === 'Ditindak').length;
    const belum = filteredReportData.filter(r => r.status === 'Belum Ditindak').length;
    return { total, ditindak, belum };
  }, [filteredReportData]);

  const rankings = useMemo(() => {
    if (activeTab === 'monitoring' || activeTab === 'guru') return { students: [], classes: [] };
    
    let source = activeTab === 'kbm' 
      ? filteredKbmData.filter(d => d.status === rankFilter) 
      : filteredReportData.filter(d => rankFilter === 'Semua' || d.category === rankFilter);
    
    const sCounts: Record<string, any> = {};
    const cCounts: Record<string, any> = {};

    source.forEach(item => {
      const sId = (item as any).studentId;
      if (sId) {
        if (!sCounts[sId]) {
          const s = data.students.find(std => std.id === sId);
          sCounts[sId] = { name: s?.name || 'N/A', count: 0, sub: s?.formalClass || 'N/A' };
        }
        sCounts[sId].count++;
      }
      const cls = (item as any).class || data.students.find(s => s.id === (item as any).studentId)?.formalClass;
      if (cls) {
        if (!cCounts[cls]) cCounts[cls] = { name: cls, count: 0, sub: 'Unit Kelas' };
        cCounts[cls].count++;
      }
    });

    return {
      students: Object.values(sCounts).sort((a, b) => b.count - a.count).slice(0, 5),
      classes: Object.values(cCounts).sort((a, b) => b.count - a.count).slice(0, 5)
    };
  }, [activeTab, rankFilter, filteredKbmData, filteredReportData, data.students]);

  const exportExcel = (exportData: any[], fileName: string) => {
    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Log");
    XLSX.writeFile(wb, `${fileName}_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6 pb-32 animate-in fade-in duration-500">
      
      {/* 1. GREEN HEADER */}
      <div className="bg-[#064e3b] p-8 md:p-14 rounded-[2.5rem] md:rounded-[4rem] text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div className="text-center md:text-left space-y-4">
             <div className="inline-flex items-center gap-3 px-5 py-2 bg-white/10 rounded-full border border-white/10 backdrop-blur-sm">
                <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></div>
                <span className="text-[9px] font-black uppercase tracking-[0.3em]">Smart Report Mahasina</span>
             </div>
             <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight leading-[0.9]">Dashboard<br/><span className="text-emerald-400">Pusat Informasi</span></h1>
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-white/10 backdrop-blur-md border border-white/10 p-6 rounded-3xl text-center">
                <p className="text-[9px] font-black uppercase tracking-widest text-emerald-300 mb-2">Santri Aktif</p>
                <div className="flex items-center justify-center gap-3">
                   <Users size={20} className="text-white/60" />
                   <h4 className="text-2xl md:text-4xl font-black">{data.students.length}</h4>
                </div>
             </div>
             <div className="bg-white/10 backdrop-blur-md border border-white/10 p-6 rounded-3xl text-center">
                <p className="text-[9px] font-black uppercase tracking-widest text-emerald-300 mb-2">Petugas Aktif</p>
                <div className="flex items-center justify-center gap-3">
                   <GraduationCap size={20} className="text-white/60" />
                   <h4 className="text-2xl md:text-4xl font-black">{data.teachers.length}</h4>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* 2. TAB NAVIGATION */}
      <div className="flex justify-center px-4">
        <div className="bg-white p-2 rounded-[2.2rem] shadow-xl border border-slate-100 flex flex-wrap justify-center gap-1">
          {[
            { id: 'kbm', label: 'ABSEN SANTRI' },
            { id: 'guru', label: 'ABSEN GURU' },
            ...(isAdmin ? [{ id: 'monitoring', label: 'MONITORING' }] : []),
            { id: 'pelanggaran', label: 'PELANGGARAN' },
            { id: 'prestasi', label: 'PRESTASI' }
          ].map(tab => (
            <button 
              key={tab.id} 
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 md:px-10 py-4 rounded-[1.8rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab.id ? 'bg-[#064e3b] text-white shadow-lg scale-105' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 3. MONITORING VIEW (SPECIAL FOR ADMIN) */}
      {activeTab === 'monitoring' && isAdmin && (
        <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
           {/* Monitoring Filter Bar */}
           <div className="bg-white p-6 md:p-8 rounded-[2rem] border shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-3">
                 <ShieldAlert className="text-amber-500" size={24} />
                 <div>
                    <h3 className="text-sm font-black uppercase text-slate-800 leading-none">Filter Monitoring</h3>
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Pilih tanggal pemantauan log sistem</p>
                 </div>
              </div>
              <div className="w-full md:w-auto">
                 <input 
                    type="date" 
                    value={monitoringDate} 
                    onChange={e => setMonitoringDate(e.target.value)} 
                    className="w-full md:w-64 p-4 bg-slate-50 border-2 border-transparent rounded-2xl text-[10px] font-black uppercase outline-none focus:border-emerald-600 shadow-inner appearance-none cursor-pointer transition-all" 
                 />
              </div>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white p-8 md:p-10 rounded-[3rem] border shadow-sm space-y-6">
                 <div className="flex items-center justify-between border-b pb-6">
                    <div className="flex items-center gap-3">
                       <BookOpen className="text-[#064e3b]" size={24} />
                       <h3 className="text-lg font-black uppercase text-slate-800">Status Absen Kelas</h3>
                    </div>
                    <div className="text-right">
                       <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">{monitoringData.dayName}, {monitoringData.dateStr}</span>
                    </div>
                 </div>
                 <div className="space-y-3 max-h-[500px] overflow-y-auto no-scrollbar">
                    {monitoringData.classes.map((s, idx) => (
                      <div key={idx} className="flex items-center justify-between p-5 bg-slate-50/50 rounded-2xl border border-slate-100 hover:bg-white hover:shadow-md transition-all">
                        <div className="min-w-0">
                           <p className="text-[11px] font-black text-slate-800 uppercase leading-none mb-1">{s.class} - {s.subject}</p>
                           <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{s.sessionType} • {s.time}</p>
                        </div>
                        <span className={`px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-2 ${s.status === 'Sudah Absen' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600 animate-pulse'}`}>
                           {s.status === 'Sudah Absen' ? <CheckCircle2 size={12} /> : <AlertCircle size={12} />}
                           {s.status}
                        </span>
                      </div>
                    ))}
                    {monitoringData.classes.length === 0 && <EmptyState msg="Tidak ada jadwal hari ini" />}
                 </div>
              </div>

              <div className="bg-white p-8 md:p-10 rounded-[3rem] border shadow-sm space-y-6">
                 <div className="flex items-center justify-between border-b pb-6">
                    <div className="flex items-center gap-3">
                       <User className="text-[#064e3b]" size={24} />
                       <h3 className="text-lg font-black uppercase text-slate-800">Status Presensi Guru</h3>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mandiri Mahasina</span>
                 </div>
                 <div className="space-y-3 max-h-[500px] overflow-y-auto no-scrollbar">
                    {monitoringData.teachers.map((s, idx) => (
                      <div key={idx} className="flex items-center justify-between p-5 bg-slate-50/50 rounded-2xl border border-slate-100 hover:bg-white hover:shadow-md transition-all">
                        <div className="min-w-0">
                           <p className="text-[11px] font-black text-slate-800 uppercase leading-none mb-1">{s.teacherName}</p>
                           <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{s.subject} • Unit {s.class}</p>
                        </div>
                        <span className={`px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-2 ${s.status === 'Sudah Absen' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600 animate-pulse'}`}>
                           {s.status === 'Sudah Absen' ? <CheckCircle2 size={12} /> : <AlertCircle size={12} />}
                           {s.status}
                        </span>
                      </div>
                    ))}
                    {monitoringData.teachers.length === 0 && <EmptyState msg="Tidak ada jadwal hari ini" />}
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* 4. STATISTICS VIEW (FOR KBM, GURU, PELANGGARAN, PRESTASI) */}
      {activeTab !== 'monitoring' && (
        <>
          <div className="bg-white p-8 md:p-12 rounded-[2.5rem] border shadow-sm space-y-8">
            <div className="flex items-center gap-3">
              <Filter size={18} className="text-emerald-900" />
              <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Filter Statistik</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <FilterGroup label="Periode" value={timeFilter} onChange={setTimeFilter} options={['today', 'week', 'month', 'semester', 'custom']} labels={['HARI INI', 'PEKAN', 'BULAN', 'SEMESTER', 'KALENDER']} />
              {timeFilter === 'custom' && (
                 <div className="space-y-1.5 animate-in slide-in-from-top-2">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Pilih Tanggal</p>
                    <input type="date" value={customDate} onChange={e => setCustomDate(e.target.value)} className="w-full p-3.5 bg-slate-50 border-2 border-transparent rounded-2xl text-[10px] font-bold outline-none focus:border-emerald-600 shadow-inner" />
                 </div>
              )}
              {activeTab === 'kbm' && <FilterGroup label="Tingkatan" value={levelFilter} onChange={setLevelFilter} options={['Semua', 'MTs', 'MA']} />}
              {activeTab === 'kbm' && <FilterGroup label="Gender" value={genderFilter} onChange={setGenderFilter} options={['Semua', 'Putra', 'Putri']} />}
              <FilterGroup label="Sesi" value={sessionFilter} onChange={setSessionFilter} options={['Semua', ...Array.from(new Set(data.schedules.map(s => s.sessionType)))]} />
              <FilterGroup label="Unit Kelas" value={classFilter} onChange={setClassFilter} options={['Semua', ...Array.from(new Set(data.students.map(s => s.formalClass))).sort()]} />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {activeTab === 'kbm' && (Object.entries(kbmStats) as [string, number][]).map(([label, val], idx) => <StatCard key={label} label={label} value={val} color={COLORS[idx % COLORS.length]} />)}
            {activeTab === 'guru' && (Object.entries(teacherStats) as [string, number][]).map(([label, val], idx) => <StatCard key={label} label={label} value={val} color={COLORS[idx % COLORS.length]} />)}
            {(activeTab === 'pelanggaran' || activeTab === 'prestasi') && (
              <>
                <StatCard label="Total Laporan" value={reportStats.total} color="#064e3b" />
                <StatCard label="Selesai Ditindak" value={reportStats.ditindak} color="#10b981" />
                <StatCard label="Menunggu Tindakan" value={reportStats.belum} color="#ef4444" />
              </>
            )}
          </div>

          {/* RANKINGS SECTION (HIDDEN FOR GURU TAB) */}
          {activeTab !== 'guru' && (
            <div className="bg-white p-8 md:p-14 rounded-[3rem] border shadow-sm space-y-12">
               <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
                  <div className="space-y-2">
                     <h3 className="text-xl font-black uppercase tracking-tight text-slate-800">Ranking Tertinggi</h3>
                     <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Berdasarkan frekuensi laporan</p>
                  </div>
                  <div className="w-full md:w-auto overflow-x-auto no-scrollbar py-1">
                     <div className="flex bg-slate-50 p-2 rounded-[1.75rem] gap-1 border border-slate-100 shadow-inner">
                        {(activeTab === 'kbm' ? ['Alpha', 'Terlambat', 'Izin', 'Sakit'] : ['Semua', ...Object.values(ViolationCategory)]).map(f => (
                          <button key={f} onClick={() => setRankFilter(f)} className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase whitespace-nowrap transition-all ${rankFilter === f ? 'bg-[#064e3b] text-white shadow-lg scale-105' : 'text-slate-400 hover:text-slate-600 hover:bg-white'}`}>{f.toUpperCase()}</button>
                        ))}
                     </div>
                  </div>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                  <div className="space-y-6">
                     <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-800 border-b pb-4">Top 5 Santri ({rankFilter})</h4>
                     <div className="space-y-3">
                        {rankings.students.map((r, i) => <RankingCard key={i} rank={i+1} name={r.name} sub={r.sub} count={r.count} isAchievement={activeTab === 'prestasi'} />)}
                        {rankings.students.length === 0 && <EmptyState msg="Belum ada data" />}
                     </div>
                  </div>
                  <div className="space-y-6">
                     <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-800 border-b pb-4">Top 5 Kelas ({rankFilter})</h4>
                     <div className="space-y-3">
                        {rankings.classes.map((r, i) => <RankingCard key={i} rank={i+1} name={r.name} sub={r.sub} count={r.count} isAchievement={activeTab === 'prestasi'} />)}
                        {rankings.classes.length === 0 && <EmptyState msg="Belum ada data" />}
                     </div>
                  </div>
               </div>
            </div>
          )}

          {/* TABLE LOG SECTION */}
          <div className="bg-white rounded-[3rem] border shadow-sm overflow-hidden">
            <div className="p-8 md:p-12 border-b flex flex-col md:flex-row justify-between items-center gap-6">
               <h3 className="text-lg font-black uppercase tracking-widest text-slate-800">Arsip Detail Laporan</h3>
               <button onClick={() => exportExcel(activeTab === 'kbm' ? filteredKbmData : activeTab === 'guru' ? filteredTeacherData : filteredReportData, `Laporan_${activeTab}`)} className="px-10 py-5 bg-[#064e3b] text-white rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-4 shadow-xl active:scale-95 transition-all hover:bg-emerald-800"><Download size={18} /> UNDUH EXCEL (.XLSX)</button>
            </div>
            <div className="overflow-x-auto no-scrollbar p-2">
              <table className="w-full text-left border-collapse min-w-[900px]">
                <thead className="bg-slate-50 border-b">
                  <tr className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]"><th className="p-8">Tanggal</th><th className="p-8">Identitas</th><th className="p-8">Detail</th><th className="p-8 text-center">Status</th><th className="p-8">Validator</th></tr>
                </thead>
                <tbody className="divide-y text-[12px] font-bold text-slate-700">
                   {(activeTab === 'kbm' ? filteredKbmData : activeTab === 'guru' ? filteredTeacherData : filteredReportData).slice(0, 50).map((item, idx) => (
                     <tr key={idx} className="hover:bg-slate-50 transition-colors">
                       <td className="p-8"><div className="flex items-center gap-2 mb-1"><Calendar size={12} className="text-emerald-600"/> {item.date}</div><div className="flex items-center gap-2 opacity-50 uppercase text-[9px] font-black"><Clock size={12}/> {item.time || (item as any).recordedTime || (item as any).startTime} WIB</div></td>
                       <td className="p-8"><p className="font-black uppercase text-slate-900 mb-1">{(item as any).teacherName || data.students.find(s => s.id === (item as any).studentId)?.name || 'N/A'}</p><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{(item as any).class || data.students.find(s => s.id === (item as any).studentId)?.formalClass}</p></td>
                       <td className="p-8"><p className="uppercase text-[10px] font-black text-emerald-800 mb-1">{(item as any).sessionType || (item as any).category || (item as any).subject || 'Umum'}</p><p className="text-[10px] font-bold text-slate-400 line-clamp-1 italic">{(item as any).summary || (item as any).description || (item as any).note || '-'}</p></td>
                       <td className="p-8 text-center"><span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest ${item.status === 'Alpha' || item.status === 'Belum Ditindak' ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'}`}>{item.status || 'Hadir'}</span></td>
                       <td className="p-8"><div className="flex items-center gap-2 text-slate-400 uppercase text-[10px] font-black"><User size={12}/> {item.recordedBy || (item as any).reporter || (item as any).teacherName || 'Sistem'}</div></td>
                     </tr>
                   ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

const StatCard: React.FC<{ label: string, value: number, color: string }> = ({ label, value, color }) => (
  <div className="bg-white p-6 md:p-8 rounded-[2rem] border-l-[10px] shadow-sm flex flex-col justify-center" style={{ borderLeftColor: color }}>
     <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 leading-none">{label}</p>
     <h4 className="text-2xl md:text-3xl font-black text-slate-800 leading-none">{value}</h4>
  </div>
);

const RankingCard = ({ rank, name, sub, count, isAchievement }: any) => (
  <div className="flex items-center justify-between p-5 bg-slate-50/50 rounded-[2rem] border border-slate-100 group hover:border-emerald-200 hover:bg-white hover:shadow-xl transition-all">
     <div className="flex items-center gap-5">
        <div className="w-12 h-12 rounded-2xl bg-white border flex items-center justify-center font-black text-slate-400 text-sm group-hover:bg-[#064e3b] group-hover:text-white transition-all shadow-sm">{rank}</div>
        <div className="min-w-0">
           <p className="text-[12px] font-black text-slate-800 uppercase leading-none mb-1.5 truncate max-w-[130px] md:max-w-[200px]">{name}</p>
           <p className="text-[9px] font-bold text-slate-400 uppercase leading-none tracking-widest">{sub}</p>
        </div>
     </div>
     <div className="text-right">
        <p className="text-base font-black text-[#064e3b] leading-none">{count}</p>
        <p className="text-[8px] font-black text-slate-300 uppercase leading-none mt-1">TOTAL</p>
     </div>
  </div>
);

const EmptyState = ({ msg }: { msg: string }) => (
  <div className="py-16 flex flex-col items-center justify-center opacity-10 space-y-4">
     <Users size={48} />
     <p className="text-[11px] font-black uppercase tracking-[0.2em]">{msg}</p>
  </div>
);

const FilterGroup = ({ label, value, onChange, options, labels }: any) => (
  <div className="space-y-1.5">
     <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">{label}</p>
     <div className="relative">
       <select value={value} onChange={e => onChange(e.target.value)} className="w-full p-3.5 bg-slate-50 border-2 border-transparent rounded-2xl text-[10px] font-black uppercase outline-none shadow-inner appearance-none cursor-pointer focus:border-emerald-600 transition-all">
          {options.map((opt: string, i: number) => <option key={opt} value={opt}>{labels ? labels[i] : opt.toUpperCase()}</option>)}
       </select>
       <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 pointer-events-none" />
     </div>
  </div>
);

export default Dashboard;
