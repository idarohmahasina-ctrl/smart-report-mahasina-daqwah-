
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Schedule, TeacherAttendance, AppData, UserProfile, AttendanceStatus 
} from './utils/types.ts';
import { 
  Lock, Clock, Coffee, ChevronRight, Calendar, Filter, UserCheck, Thermometer, FileText, AlertTriangle
} from 'lucide-react';
import { isTeacherMatch } from './utils/nameMatchers.ts';

interface TeacherAttendanceProps {
  data: AppData;
  profile: UserProfile;
  onSave: (rec: TeacherAttendance) => void;
}

const DAYS_ORDER = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Ahad'];

const TeacherAttendanceView: React.FC<TeacherAttendanceProps> = ({ data, profile, onSave }) => {
  const [activeTab, setActiveTab] = useState<'today' | 'schedule' | 'history'>('today');
  const [scheduleDayFilter, setScheduleDayFilter] = useState('Semua');
  const [note, setNote] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<AttendanceStatus>(AttendanceStatus.H);
  const [photo, setPhoto] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const todayNameRaw = new Intl.DateTimeFormat('id-ID', { weekday: 'long' }).format(new Date());
  const todayName = todayNameRaw === 'Minggu' ? 'Ahad' : todayNameRaw;
  
  const isAdmin = profile.email.toLowerCase().trim() === 'idarohmahasina@gmail.com';

  const isTimeValid = (timeRange: string) => {
    if (isAdmin) return true;
    try {
      const [start] = timeRange.split(' - ');
      const [sH, sM] = start.split(':').map(Number);
      const nowH = currentTime.getHours();
      const nowM = currentTime.getMinutes();
      return (nowH * 60 + nowM) >= (sH * 60 + sM - 30);
    } catch (e) { return false; }
  };

  const mySchedules = useMemo(() => {
    if (isAdmin) return data.schedules;
    return data.schedules.filter(s => isTeacherMatch(profile.fullName, s.teacherName));
  }, [data.schedules, profile.fullName, isAdmin]);

  const todaySchedules = useMemo(() => mySchedules.filter(s => s.day === todayName), [mySchedules, todayName]);

  const filteredSchedules = useMemo(() => {
    let result = mySchedules;
    if (scheduleDayFilter !== 'Semua') {
      result = result.filter(s => s.day === scheduleDayFilter);
    }
    
    return [...result].sort((a, b) => {
      const dayA = DAYS_ORDER.indexOf(a.day);
      const dayB = DAYS_ORDER.indexOf(b.day);
      if (dayA !== dayB) return dayA - dayB;
      const [startA] = a.time.split(':').map(Number);
      const [startB] = b.time.split(':').map(Number);
      return (startA || 0) - (startB || 0);
    });
  }, [mySchedules, scheduleDayFilter]);

  const handleStatusSelect = (status: AttendanceStatus) => {
    if (status === AttendanceStatus.LIBUR) {
      const confirmLibur = window.confirm(
        "Apakah Anda yakin ingin meliburkan sesi ini?\n\nCatatan: Jika Anda berhalangan, sesi ini sebenarnya dapat diisi oleh Guru Asisten/Badal yang memiliki akses. Tombol LIBUR hanya digunakan jika ada kebijakan resmi libur dari lembaga."
      );
      if (!confirmLibur) return;
    }
    setSelectedStatus(status);
  };

  const submitAttendance = (s: Schedule) => {
    const newRecord: TeacherAttendance = {
      id: `ta-${Date.now()}`,
      date: new Date().toLocaleDateString('id-ID'),
      teacherEmail: profile.email,
      teacherName: profile.fullName,
      subject: s.subject,
      class: s.class,
      sessionType: s.sessionType,
      startTime: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      summary: note || selectedStatus,
      status: selectedStatus,
      photoUrl: photo || undefined
    };
    onSave(newRecord);
    alert(`Laporan [${selectedStatus}] pengajar berhasil terkirim.`);
    setPhoto(null);
    setNote('');
    setSelectedStatus(AttendanceStatus.H);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-32">
      <div className="bg-[#064e3b] p-8 md:p-12 rounded-[2.5rem] md:rounded-[3.5rem] shadow-xl text-white text-center space-y-4">
          <h2 className="text-xl md:text-3xl font-black uppercase tracking-tight leading-none">Presensi Pengajar</h2>
          <p className="text-[9px] md:text-[11px] font-black text-emerald-400 uppercase tracking-[0.3em] leading-none">Sistem Pelaporan Mandiri Mahasina</p>
      </div>

      <div className="bg-white p-1.5 rounded-2xl shadow-sm flex gap-1 border border-slate-100 overflow-x-auto no-scrollbar max-w-2xl mx-auto">
        {[
          { id: 'today', label: 'INPUT ABSEN' },
          { id: 'schedule', label: 'JADWAL SAYA' },
          { id: 'history', label: 'RIWAYAT' },
        ].map((tab) => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-4 px-6 rounded-xl whitespace-nowrap text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab.id ? 'bg-[#064e3b] text-white shadow-md scale-[1.02]' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {activeTab === 'today' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-5xl mx-auto">
          {todaySchedules.map((s) => {
            const active = isTimeValid(s.time);
            return (
              <div key={s.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6 relative overflow-hidden text-left">
                <div className="flex justify-between items-start border-b border-slate-50 pb-6">
                  <div className="min-w-0">
                    <p className="text-[9px] font-black text-emerald-600 uppercase tracking-[0.2em] leading-none mb-3">{s.sessionType}</p>
                    <h3 className="text-sm md:text-base font-black text-slate-800 uppercase truncate mb-2">{s.subject}</h3>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Unit: {s.class} • Jam: {s.time}</p>
                  </div>
                  {!active && <div className="p-3 bg-red-50 text-red-400 rounded-xl shadow-inner"><Lock size={20}/></div>}
                </div>

                <div className={`space-y-6 ${!active ? 'opacity-40 pointer-events-none' : ''}`}>
                  <div className="space-y-3">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Pilih Status Kehadiran</p>
                    <div className="grid grid-cols-2 gap-2">
                       <button onClick={() => handleStatusSelect(AttendanceStatus.H)} className={`flex items-center justify-center gap-2 py-4 rounded-2xl text-[10px] font-black uppercase border transition-all ${selectedStatus === AttendanceStatus.H ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg' : 'bg-slate-50 text-slate-400'}`}>
                          <UserCheck size={16}/> Hadir
                       </button>
                       <button onClick={() => handleStatusSelect(AttendanceStatus.S)} className={`flex items-center justify-center gap-2 py-4 rounded-2xl text-[10px] font-black uppercase border transition-all ${selectedStatus === AttendanceStatus.S ? 'bg-amber-500 text-white border-amber-500 shadow-lg' : 'bg-slate-50 text-slate-400'}`}>
                          <Thermometer size={16}/> Sakit
                       </button>
                       <button onClick={() => handleStatusSelect(AttendanceStatus.I)} className={`flex items-center justify-center gap-2 py-4 rounded-2xl text-[10px] font-black uppercase border transition-all ${selectedStatus === AttendanceStatus.I ? 'bg-blue-500 text-white border-blue-500 shadow-lg' : 'bg-slate-50 text-slate-400'}`}>
                          <FileText size={16}/> Izin
                       </button>
                       <button onClick={() => handleStatusSelect(AttendanceStatus.LIBUR)} className={`flex items-center justify-center gap-2 py-4 rounded-2xl text-[10px] font-black uppercase border transition-all ${selectedStatus === AttendanceStatus.LIBUR ? 'bg-slate-800 text-white border-slate-800 shadow-lg' : 'bg-slate-50 text-slate-400'}`}>
                          <Coffee size={16}/> Libur
                       </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <button onClick={() => fileInputRef.current?.click()} className="flex-1 py-4 bg-slate-50 text-slate-500 rounded-2xl text-[10px] font-black uppercase tracking-widest border shadow-inner transition-all hover:bg-slate-100">{photo ? 'FOTO OK' : 'AMBIL FOTO'}</button>
                      <input type="file" ref={fileInputRef} onChange={(e) => { const f = e.target.files?.[0]; if(f) { const r = new FileReader(); r.onloadend = () => setPhoto(r.result as string); r.readAsDataURL(f); } }} accept="image/*" className="hidden" />
                    </div>
                    <textarea placeholder="Tuliskan keterangan / jurnal KBM hari ini..." className="w-full p-5 bg-slate-50 rounded-2xl text-[11px] font-bold outline-none border border-transparent focus:border-emerald-600 shadow-inner h-28 resize-none transition-all" value={note} onChange={e => setNote(e.target.value)} />
                  </div>
                  
                  <button onClick={() => submitAttendance(s)} className={`w-full py-5 text-white rounded-2xl text-[11px] font-black uppercase tracking-[0.25em] shadow-xl transition-all active:scale-95 leading-none ${selectedStatus === AttendanceStatus.H ? 'bg-[#064e3b] hover:bg-emerald-800' : 'bg-slate-700 hover:bg-slate-900'}`}>
                    KONFIRMASI LAPORAN
                  </button>
                </div>
              </div>
            );
          })}
          {todaySchedules.length === 0 && (
             <div className="col-span-full py-32 text-center opacity-40 uppercase text-[12px] font-black tracking-[0.5em] leading-relaxed">
                Tidak Ada Jadwal Mengajar<br/>Hari Ini
             </div>
          )}
        </div>
      )}

      {activeTab === 'schedule' && (
        <div className="space-y-6 max-w-6xl mx-auto px-2">
          <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center gap-3 px-1">
              <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center">
                <Filter size={14} />
              </div>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Filter Jadwal Per Hari</p>
            </div>
            <div className="flex bg-slate-50 p-1.5 rounded-2xl gap-1 overflow-x-auto no-scrollbar border border-slate-100">
              {['Semua', ...DAYS_ORDER].map(day => (
                <button 
                  key={day} 
                  onClick={() => setScheduleDayFilter(day)}
                  className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase transition-all whitespace-nowrap ${scheduleDayFilter === day ? 'bg-[#064e3b] text-white shadow-lg scale-105' : 'text-slate-400 hover:text-emerald-950 hover:bg-white/50'}`}
                >
                  {day}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSchedules.map((s) => (
              <div key={s.id} className="bg-white p-7 rounded-[2.5rem] border border-slate-100 flex items-center justify-between shadow-sm hover:shadow-md transition-all text-left group">
                 <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                       <Calendar size={12} className="text-emerald-600" />
                       <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest leading-none">{s.day}</p>
                    </div>
                    <h4 className="text-[13px] font-black text-slate-800 uppercase truncate mb-1.5">{s.subject}</h4>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">{s.time} • Unit {s.class}</p>
                 </div>
                 <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-200 group-hover:bg-[#064e3b] group-hover:text-white transition-all shadow-inner">
                    <ChevronRight size={18} />
                 </div>
              </div>
            ))}
            {filteredSchedules.length === 0 && (
              <div className="col-span-full py-40 text-center opacity-30 text-[10px] font-black uppercase tracking-[0.3em] bg-white/40 rounded-[3rem] border-2 border-dashed border-slate-100">
                Data jadwal tidak ditemukan<br/>untuk filter {scheduleDayFilter}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="max-w-4xl mx-auto space-y-4 px-2">
           {data.teacherAttendance
             .filter(a => isAdmin || a.teacherEmail === profile.email)
             .sort((a,b) => b.id.localeCompare(a.id))
             .slice(0, 20)
             .map((h, i) => (
               <div key={i} className="bg-white p-7 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between text-left hover:border-emerald-100 transition-all">
                  <div className="min-w-0">
                     <p className="text-[9px] font-black text-slate-400 uppercase mb-2 leading-none">{h.date} • {h.startTime} WIB</p>
                     <h4 className="text-[13px] font-black text-slate-800 uppercase leading-none mb-2">{h.subject}</h4>
                     <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest leading-none">{h.class} • {h.status}</p>
                     <p className="text-[9px] text-slate-400 mt-1 line-clamp-1 italic">{h.summary}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border-2 ${h.status === AttendanceStatus.H ? 'border-emerald-100 text-emerald-500 bg-emerald-50' : 'border-amber-100 text-amber-500 bg-amber-50'}`}>
                     <Clock size={18} />
                  </div>
               </div>
           ))}
           {data.teacherAttendance.length === 0 && (
              <div className="py-32 text-center opacity-30 text-[10px] font-black uppercase tracking-[0.3em]">
                Belum ada riwayat presensi
              </div>
           )}
        </div>
      )}
    </div>
  );
};

export default TeacherAttendanceView;
