import { db, isAIStudio } from './firebase';
import { 
  doc, setDoc, onSnapshot, getDoc, collection, getDocs, deleteDoc, query, where, orderBy, limit, addDoc, updateDoc, serverTimestamp 
} from "firebase/firestore";
import { 
  UserProfile, AppData, Student, AttendanceRecord, ReportItem, TeacherAttendance, PrayerRecord, Schedule, UserRole 
} from '../views/utils/types';
import { 
  DEMO_STUDENTS, DEMO_TEACHERS, DEMO_SCHEDULES, 
  DEMO_ATTENDANCE, DEMO_REPORTS, DEMO_TEACHER_ATTENDANCE, DEMO_PRAYER 
} from './components/constants';

const SESSION_KEY = 'mahasina_active_session_v4';

const isDbAvailable = () => db !== null;

export const getUserByEmail = async (email: string): Promise<UserProfile | null> => {
  if (isAIStudio || !isDbAvailable()) {
    return {
      id: 'demo-user',
      fullName: 'Demo User (AI Studio)',
      email: email.toLowerCase().trim(),
      phone: '0812345678',
      role: email.toLowerCase().trim() === 'idarohmahasina@gmail.com' ? UserRole.IDAROH : UserRole.GURU
    };
  }
  
  try {
    const cleanEmail = email.toLowerCase().trim();
    const docRef = doc(db!, "users", cleanEmail);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) return docSnap.data() as UserProfile;
  } catch (e) {
    console.warn("Firestore Error:", e);
  }
  return null;
};

export const subscribeToCollection = (collectionName: string, callback: (data: any[]) => void) => {
  if (isAIStudio || !isDbAvailable()) {
    setTimeout(() => {
      if (collectionName === 'master') {
        callback([
          { id: 'students', items: DEMO_STUDENTS },
          { id: 'teachers', items: DEMO_TEACHERS },
          { id: 'schedules', items: DEMO_SCHEDULES }
        ]);
      } else if (collectionName === 'attendance') callback(DEMO_ATTENDANCE);
      else if (collectionName === 'reports') callback(DEMO_REPORTS);
      else if (collectionName === 'teacherAttendance') callback(DEMO_TEACHER_ATTENDANCE);
      else if (collectionName === 'prayerAttendance') callback(DEMO_PRAYER);
      else if (collectionName === 'config') callback([{ id: 'academic', semester: 'Ganjil', schoolYear: '2024/2025' }]);
      else callback([]);
    }, 50);
    return () => {};
  }

  const q = query(collection(db!, collectionName), limit(1000));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  }, () => callback([]));
};

export const setActiveSession = (u: UserProfile | null) => {
  if (u) localStorage.setItem(SESSION_KEY, JSON.stringify(u));
  else localStorage.removeItem(SESSION_KEY);
};

export const getActiveSession = (): UserProfile | null => {
  try {
    const s = localStorage.getItem(SESSION_KEY);
    return s ? JSON.parse(s) : null;
  } catch (e) {
    return null;
  }
};

export const registerUser = async (profile: UserProfile) => {
  if (isAIStudio || !isDbAvailable()) return;
  const cleanEmail = profile.email.toLowerCase().trim();
  await setDoc(doc(db!, "users", cleanEmail), { ...profile, lastActive: serverTimestamp() }, { merge: true });
};

export const saveAppData = async (update: Partial<AppData>) => {
  if (isAIStudio || !isDbAvailable()) return;
  // ... implementasi firestore
};

export const clearAppData = () => {
  localStorage.removeItem(SESSION_KEY);
};

export const updateSingleRecord = async (c: string, id: string, d: any) => { if (!isAIStudio && isDbAvailable()) await updateDoc(doc(db!, c, id), d); };
export const deleteSingleRecord = async (c: string, id: string) => { if (!isAIStudio && isDbAvailable()) await deleteDoc(doc(db!, c, id)); };
export const saveMasterList = async (t: string, d: any[]) => { if (!isAIStudio && isDbAvailable()) await setDoc(doc(db!, "master", t), { items: d }); };
export const getAllUsers = async () => isAIStudio || !isDbAvailable() ? [] : (await getDocs(collection(db!, "users"))).docs.map(d => d.data() as UserProfile);
export const deleteUser = async (e: string) => { if (!isAIStudio && isDbAvailable()) await deleteDoc(doc(db!, "users", e.toLowerCase().trim())); };
export const resetFirestoreData = async () => {};
