
import { initializeApp, getApp, getApps, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth, GoogleAuthProvider } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyAwOMwPEbm48cj_M3wUnOXTpZJiMzaRzBc",
  authDomain: "smart-report-mahasina-1c0df.firebaseapp.com",
  projectId: "smart-report-mahasina-1c0df",
  storageBucket: "smart-report-mahasina-1c0df.firebasestorage.app",
  messagingSenderId: "643256435966",
  appId: "1:643256435966:web:692bc2c71c47c172da51af"
};

export const isAIStudio = 
  typeof window !== 'undefined' && (
    window.location.hostname.includes("aistudio") || 
    window.location.hostname.includes("studio.google.com") ||
    window.location.hostname.includes("google.com")
  );

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;

if (isAIStudio) {
  console.log("🍦 Firebase OFF (AI Studio mode): Running with local mock data");
} else {
  try {
    app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
    db = getFirestore(app);
    auth = getAuth(app);
    console.log("🔥 Firebase ON: Connected to Cloud Database (Production Mode)");
  } catch (e) {
    console.warn("⚠️ Firebase Initialization Failed:", e);
  }
}

export { db, auth };
export const googleProvider = new GoogleAuthProvider();
