
import React, { useState } from 'react';
import { APP_LOGO } from './constants.tsx';
import { UserRole, AcademicConfig } from '../../views/utils/types.ts';
import { 
  Menu, X
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  role: UserRole;
  userName: string;
  userEmail: string;
  onLogout: () => void;
  academicConfig: AcademicConfig;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, activeTab, setActiveTab, role, userName, userEmail, onLogout, academicConfig
}) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const isAdmin = userEmail.toLowerCase().trim() === 'idarohmahasina@gmail.com';
  
  const canSeeRecap = isAdmin || 
                     role === UserRole.PENGASUH || 
                     role === UserRole.IDAROH || 
                     role === UserRole.MUSYRIF || 
                     role === UserRole.GURU;
  
  const canSeeTeacherAttendance = role === UserRole.GURU || role === UserRole.MUSYRIF || role === UserRole.IDAROH || role === UserRole.PENGASUH;

  const menuItems = [
    { id: 'dashboard', label: 'DASHBOARD', visible: true },
    { id: 'absen-guru', label: 'ABSEN GURU', visible: canSeeTeacherAttendance },
    { id: 'absen-kbm', label: 'ABSEN KBM', visible: true },
    { id: 'absen-sholat', label: 'ABSEN PONDOK', visible: true },
    { id: 'input-pelanggaran', label: 'PELANGGARAN', visible: true },
    { id: 'input-prestasi', label: 'PRESTASI', visible: true },
    { id: 'rekap-laporan', label: 'REKAP LAPORAN', visible: canSeeRecap },
    { id: 'informasi', label: 'INFORMASI', visible: true },
    { id: 'panel-kontrol', label: 'AUDIT SYSTEM', visible: isAdmin },
    { id: 'pengaturan', label: 'PENGATURAN', visible: true },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setIsSidebarOpen(false);
  };

  return (
    <div className="flex h-screen bg-[#f8fafc] overflow-hidden font-sans select-none">
      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] lg:hidden transition-opacity" 
          onClick={() => setIsSidebarOpen(false)} 
        />
      )}
      
      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 w-64 bg-[#064e3b] text-white flex flex-col z-[70] transition-transform duration-300 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-6 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-3">
            <img src={APP_LOGO} alt="Logo" className="w-8 h-8 bg-white p-1 rounded-lg" />
            <div className="flex flex-col text-left">
              <h1 className="font-black text-xs uppercase tracking-tighter text-white">Mahasina</h1>
              <span className="text-[7px] font-bold text-emerald-400 uppercase tracking-widest leading-none">Smart Report</span>
            </div>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-1 text-emerald-100"><X size={20} /></button>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto no-scrollbar">
          {menuItems.filter(item => item.visible).map((item) => (
            <button 
              key={item.id} 
              onClick={() => handleNavClick(item.id)} 
              className={`w-full text-left px-5 py-4 rounded-xl transition-all ${activeTab === item.id ? 'bg-white text-[#064e3b] font-black shadow-lg scale-[1.02]' : 'text-emerald-100/60 hover:bg-white/5 hover:text-white'}`}
            >
              <span className="text-[10px] uppercase tracking-[0.15em] font-black">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button onClick={onLogout} className="w-full flex items-center justify-center px-5 py-4 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all">
            <span className="text-[10px] font-black uppercase tracking-widest">LOGOUT</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full relative overflow-hidden">
        {/* Header */}
        <header className="w-full flex items-center justify-between px-4 py-4 md:px-8 bg-white border-b border-slate-200 shadow-sm z-50">
          <div className="flex items-center gap-2 md:gap-3">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 text-slate-500"><Menu size={20} /></button>
            <div className="flex flex-col min-w-0 text-left">
              <h2 className="text-[10px] md:text-[11px] font-black text-slate-800 tracking-tight truncate max-w-[150px] uppercase leading-none">{userName}</h2>
              <span className="text-[7px] font-bold text-emerald-600 uppercase tracking-widest mt-1 truncate max-w-[150px]">{role}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3 shrink-0">
             <div className="hidden sm:flex flex-col text-right">
                <h3 className="text-[10px] font-black text-slate-800 uppercase leading-none">Mahasina</h3>
                <p className="text-[7px] font-bold text-slate-400 uppercase tracking-widest mt-1">Smt {academicConfig?.semester} • {academicConfig?.schoolYear}</p>
             </div>
             <img src={APP_LOGO} className="w-7 h-7 md:w-8 md:h-8 p-0.5 border border-slate-100 rounded-lg" alt="Inst" />
          </div>
        </header>

        {/* Content Body */}
        <main className="flex-1 overflow-y-auto no-scrollbar bg-[#f8fafc]">
          <div className="px-3 md:px-8 py-4 md:py-8 max-w-[1200px] mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
