import React, { useState, useEffect } from 'react';
import { UserRole, AppData, UserProfile } from './types';
import Layout from './components/Layout';
import Registration from './views/Registration';
import Dashboard from './views/utils/Dashboard';
import Attendance from './Attendance';
import Reports from './views/utils/Reports';
import Information from './views/utils/Information';
import Settings from './views/Settings';
import PrayerAttendance from './views/utils/PrayerAttendance';
import ControlPanel from './views/ControlPanel';
import RekapLaporan from './RekapLaporan';
import TeacherAttendanceView from './views/TeacherAttendance';
import { AlertCircle } from 'lucide-react';
import { 
  getActiveSession, clearAppData, subscribeToCollection, 
  saveAppData, saveMasterList, updateSingleRecord, deleteSingleRecord 
} from './services/dataService';

const App: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [dbError, setDbError] = useState<string | null>(null);
  
  const [appData, setAppData] = useState<AppData>({
    attendance: [],
    reports: [],
    students: [],
    teachers: [],
    schedules: [],
    prayerAttendance: [],
    teacherAttendance: [],
    academicConfig: { semester: 'Ganjil', schoolYear: '2024/2025' },
    violationTemplates: [],
    achievementTemplates: [],
    orsam: [],
    orklas: [],
    extraDataLists: [],
    announcements: []
  });

  useEffect(() => {
    try {
      const session = getActiveSession();
      if (session) {
        setProfile(session);
      }
    } catch (e) {
      console.error("Session load error", e);
    } finally {
      // Pastikan loading berhenti meskipun session gagal dimuat
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!profile) return;

    let unsubscribers: (() => void)[] = [];

    try {
      unsubscribers = [
        subscribeToCollection('attendance', data => setAppData(prev => ({ ...prev, attendance: data }))),
        subscribeToCollection('reports', data => setAppData(prev => ({ ...prev, reports: data }))),
        subscribeToCollection('prayerAttendance', data => setAppData(prev => ({ ...prev, prayerAttendance: data }))),
        subscribeToCollection('teacherAttendance', data => setAppData(prev => ({ ...prev, teacherAttendance: data }))),
        subscribeToCollection('master', data => {
          const students = data.find(d => d.id === 'students')?.items || [];
          const teachers = data.find(d => d.id === 'teachers')?.items || [];
          const schedules = data.find(d => d.id === 'schedules')?.items || [];
          const extraDataLists = data.find(d => d.id === 'extraDataLists')?.items || [];
          setAppData(prev => ({ ...prev, students, teachers, schedules, extraDataLists }));
        })
      ];
    } catch (err: any) {
      console.error("Firestore initialization error:", err);
      // Jangan langsung set error ke UI jika hanya satu koleksi yang gagal,
      // tapi untuk error fatal 'Service unavailable', kita tampilkan pesan.
      if (err.message?.includes('available')) {
        setDbError("Koneksi ke database gagal. Mohon pastikan internet stabil dan coba muat ulang.");
      }
    }

    return () => unsubscribers.forEach(unsub => unsub());
  }, [profile]);

  const handleLogout = () => {
    if (confirm("Anda yakin ingin keluar?")) {
      clearAppData();
      setProfile(null);
      window.location.reload();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#064e3b] flex flex-col items-center justify-center text-white space-y-4">
        <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin" />
        <p className="font-black uppercase tracking-[0.5em] text-[10px]">Menyinkronkan Data...</p>
      </div>
    );
  }

  if (dbError) {
    return (
      <div className="min-h-screen bg-red-900 flex flex-col items-center justify-center text-white p-6 text-center space-y-6">
        <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center">
          <AlertCircle size={40} />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-bold uppercase tracking-tight">Koneksi Database Gagal</h2>
          <p className="text-sm opacity-80 max-w-md">{dbError}</p>
        </div>
        <div className="flex flex-col gap-3 w-full max-w-xs">
          <button 
            onClick={() => window.location.reload()} 
            className="px-8 py-4 bg-white text-red-900 rounded-2xl font-black uppercase text-xs shadow-xl active:scale-95"
          >
            Muat Ulang Aplikasi
          </button>
          <button 
            onClick={() => { clearAppData(); window.location.reload(); }} 
            className="px-8 py-4 bg-red-800/50 text-white rounded-2xl font-black uppercase text-xs"
          >
            Reset Sesi Login
          </button>
        </div>
      </div>
    );
  }

  if (!profile) {
    return <Registration onComplete={(p) => setProfile(p)} />;
  }

  return (
    <Layout
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      role={profile.role}
      userName={profile.fullName}
      userEmail={profile.email}
      onLogout={handleLogout}
      academicConfig={appData.academicConfig}
    >
      {activeTab === 'dashboard' && <Dashboard />}
      
      {activeTab === 'absen-guru' && (
        <TeacherAttendanceView 
          data={appData} 
          profile={profile} 
          onSave={(rec, hol) => {
            saveAppData({ teacherAttendance: [rec] });
            if (hol) saveAppData({ attendance: [hol] });
          }} 
        />
      )}

      {activeTab === 'absen-kbm' && (
        <Attendance 
          {...appData} 
          role={profile.role} 
          currentUser={profile.fullName} 
          userEmail={profile.email}
          onSave={recs => saveAppData({ attendance: recs })}
          onUpdate={rec => updateSingleRecord('attendance', rec.id, rec)}
          onUpdateStudent={s => {
            const newStudents = appData.students.map(std => std.id === s.id ? s : std);
            saveMasterList('students', newStudents);
          }}
        />
      )}

      {activeTab === 'absen-sholat' && (
        <PrayerAttendance 
          students={appData.students} 
          allPrayerRecords={appData.prayerAttendance} 
          currentUser={profile.fullName} 
          onSave={recs => saveAppData({ prayerAttendance: recs })} 
        />
      )}

      {activeTab === 'input-pelanggaran' && (
        <Reports 
          type="Violation" 
          role={profile.role} 
          currentUser={profile.fullName} 
          students={appData.students} 
          allReports={appData.reports} 
          templates={appData.violationTemplates}
          schedules={appData.schedules}
          onSave={rep => saveAppData({ reports: [rep] })}
        />
      )}

      {activeTab === 'input-prestasi' && (
        <Reports 
          type="Achievement" 
          role={profile.role} 
          currentUser={profile.fullName} 
          students={appData.students} 
          allReports={appData.reports} 
          templates={appData.achievementTemplates}
          schedules={appData.schedules}
          onSave={rep => saveAppData({ reports: [rep] })}
        />
      )}

      {activeTab === 'rekap-laporan' && <RekapLaporan data={appData} profile={profile} />}

      {activeTab === 'informasi' && (
        <Information 
          role={profile.role} 
          userEmail={profile.email} 
          data={appData} 
          onUpdateData={(type, newData) => {
            if (type === 'Siswa') saveMasterList('students', newData);
            if (type === 'Guru') saveMasterList('teachers', newData);
            if (type === 'Jadwal') saveMasterList('schedules', newData);
          }} 
        />
      )}

      {activeTab === 'panel-kontrol' && (
        <ControlPanel 
          data={appData} 
          actions={{
            deleteAttendance: id => deleteSingleRecord('attendance', id),
            deletePrayer: id => deleteSingleRecord('prayerAttendance', id),
            deleteReport: id => deleteSingleRecord('reports', id),
            deleteTeacherAttendance: id => deleteSingleRecord('teacherAttendance', id),
            updateAttendance: rec => updateSingleRecord('attendance', rec.id, rec),
            updatePrayer: rec => updateSingleRecord('prayerAttendance', rec.id, rec),
            updateReport: rec => updateSingleRecord('reports', rec.id, rec),
            updateTeacherAttendance: rec => updateSingleRecord('teacherAttendance', rec.id, rec)
          }} 
        />
      )}

      {activeTab === 'pengaturan' && (
        <Settings 
          userEmail={profile.email} 
          academicConfig={appData.academicConfig} 
          onUpdateAcademic={c => saveAppData({ academicConfig: c })}
          students={appData.students}
          schedules={appData.schedules}
          availableClasses={[]}
        />
      )}
    </Layout>
  );
};

export default App;