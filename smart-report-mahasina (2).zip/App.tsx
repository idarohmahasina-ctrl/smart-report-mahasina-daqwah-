
import React, { useState, useEffect } from 'react';
import Layout from './services/components/Layout.tsx';
import Registration from './views/Registration.tsx';
import Dashboard from './views/utils/Dashboard.tsx';
import Attendance from './Attendance.tsx';
import Reports from './views/utils/Reports.tsx';
import Information from './views/Information.tsx';
import Settings from './views/Settings.tsx';
import PrayerAttendance from './views/utils/PrayerAttendance.tsx';
import ControlPanel from './views/utils/ControlPanel.tsx';
import RekapLaporan from './RekapLaporan.tsx';
import TeacherAttendanceView from './views/TeacherAttendance.tsx';
import { isAIStudio } from './services/firebase.ts';
import { 
  getActiveSession, clearAppData, subscribeToCollection, 
  saveAppData, saveMasterList, updateSingleRecord, deleteSingleRecord 
} from './services/dataService.ts';
import { AppData, UserProfile } from './views/utils/types.ts';

const App: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  
  const [appData, setAppData] = useState<AppData>({
    attendance: [],
    reports: [],
    students: [],
    teachers: [],
    schedules: [],
    prayerAttendance: [],
    teacherAttendance: [],
    academicConfig: { semester: 'Semester I', schoolYear: '2024/2025' },
    violationTemplates: [],
    achievementTemplates: [],
    orsam: [],
    orklas: [],
    extraDataLists: [],
    announcements: []
  });

  useEffect(() => {
    const initApp = async () => {
      try {
        const session = getActiveSession();
        if (session) {
          setProfile(session);
        }
      } catch (e) {
        console.error("Gagal memuat sesi:", e);
      } finally {
        setTimeout(() => setLoading(false), 1000);
      }
    };
    initApp();
  }, []);

  useEffect(() => {
    if (!profile) return;
    
    const unsubscribers = [
      subscribeToCollection('attendance', data => setAppData(p => ({ ...p, attendance: data }))),
      subscribeToCollection('reports', data => setAppData(p => ({ ...p, reports: data }))),
      subscribeToCollection('prayerAttendance', data => setAppData(p => ({ ...p, prayerAttendance: data }))),
      subscribeToCollection('teacherAttendance', data => setAppData(p => ({ ...p, teacherAttendance: data }))),
      subscribeToCollection('master', data => {
        const students = data.find(d => d.id === 'students')?.items || [];
        const teachers = data.find(d => d.id === 'teachers')?.items || [];
        const schedules = data.find(d => d.id === 'schedules')?.items || [];
        setAppData(p => ({ ...p, students, teachers, schedules }));
      }),
      subscribeToCollection('config', data => {
        const academic = data.find(d => d.id === 'academic');
        if (academic) setAppData(p => ({ ...p, academicConfig: academic }));
      })
    ];
    return () => unsubscribers.forEach(u => u());
  }, [profile]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#064e3b] flex flex-col items-center justify-center text-white p-6">
        <div className="text-center space-y-6">
          <div className="w-14 h-14 border-4 border-white/20 border-t-white rounded-full animate-spin mx-auto shadow-xl" />
          <div className="space-y-1">
            <p className="font-black uppercase tracking-[0.4em] text-[10px] md:text-[12px] animate-pulse">Menyiapkan Sistem</p>
            <p className="text-white/40 text-[8px] font-bold uppercase tracking-widest">Memuat database Mahasina...</p>
          </div>
        </div>
      </div>
    );
  }
  
  if (!profile) {
    return <Registration onComplete={(p) => setProfile(p)} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard data={appData} profile={profile} />;
      case 'absen-guru': return <TeacherAttendanceView data={appData} profile={profile} onSave={rec => saveAppData({ teacherAttendance: [rec] })} />;
      case 'absen-kbm': return <Attendance {...appData} role={profile.role} currentUser={profile.fullName} userEmail={profile.email} onSave={recs => saveAppData({ attendance: recs })} />;
      case 'absen-sholat': return (
        <PrayerAttendance 
          students={appData.students} 
          allPrayerRecords={appData.prayerAttendance} 
          currentUser={profile.fullName} 
          userRole={profile.role} 
          onSave={recs => saveAppData({ prayerAttendance: recs })} 
          onUpdate={rec => updateSingleRecord('prayerAttendance', rec.id, rec)}
          onDelete={id => deleteSingleRecord('prayerAttendance', id)}
        />
      );
      case 'input-pelanggaran': return <Reports type="Violation" role={profile.role} currentUser={profile.fullName} students={appData.students} allReports={appData.reports} templates={appData.violationTemplates} onSave={rep => saveAppData({ reports: [rep] })} />;
      case 'input-prestasi': return <Reports type="Achievement" role={profile.role} currentUser={profile.fullName} students={appData.students} allReports={appData.reports} templates={appData.achievementTemplates} onSave={rep => saveAppData({ reports: [rep] })} />;
      case 'rekap-laporan': return <RekapLaporan data={appData} profile={profile} />;
      case 'informasi': return <Information role={profile.role} userEmail={profile.email} data={appData} onUpdateData={saveMasterList} />;
      case 'panel-kontrol': return <ControlPanel data={appData} actions={{ deleteAttendance: id => deleteSingleRecord('attendance', id), deletePrayer: id => deleteSingleRecord('prayerAttendance', id), deleteReport: id => deleteSingleRecord('reports', id), deleteTeacherAttendance: id => deleteSingleRecord('teacherAttendance', id), updateAttendance: r => updateSingleRecord('attendance', r.id, r), updatePrayer: r => updateSingleRecord('prayerAttendance', r.id, r), updateReport: r => updateSingleRecord('reports', r.id, r), updateTeacherAttendance: r => updateSingleRecord('teacherAttendance', r.id, r) }} />;
      case 'pengaturan': return <Settings userEmail={profile.email} academicConfig={appData.academicConfig} onUpdateAcademic={c => saveAppData({ academicConfig: c })} students={appData.students} schedules={appData.schedules} availableClasses={[]} />;
      default: return <Dashboard data={appData} profile={profile} />;
    }
  };

  return (
    <div className="relative min-h-screen bg-[#f8fafc] selection:bg-emerald-100 selection:text-emerald-900">
      {isAIStudio && (
        <div className="bg-amber-500 text-white text-[9px] font-black uppercase py-1.5 text-center fixed top-0 w-full z-[9999] pointer-events-none shadow-sm flex items-center justify-center gap-2">
           <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
           Mode Demo Smart Report Mahasina
        </div>
      )}
      <Layout
        activeTab={activeTab} setActiveTab={setActiveTab}
        role={profile.role} userName={profile.fullName} userEmail={profile.email}
        onLogout={() => { if(confirm("Keluar dari aplikasi?")) { clearAppData(); window.location.reload(); } }}
        academicConfig={appData.academicConfig}
      >
        <div className="max-w-[1200px] mx-auto">
          {renderContent()}
        </div>
      </Layout>
    </div>
  );
};

export default App;
